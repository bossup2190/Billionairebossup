# Liquidity Settlement Gateway: architecture

Payouts are **USDC on Ethereum**, sent through **Circle Mint**. Documents live in **AWS S3 (SSE-KMS)**. Email OTP goes through **MailerSend**.

## Flow

```mermaid
flowchart LR
  U[Operator: files + photos + name + drawn signature] -->|REST multipart| S3[S3 intake<br/>SSE-KMS]
  S3 --> X[Extraction<br/>XML / JSON / PDF text / OCR]
  X --> Z[Zod validation<br/>amount, USDC, ETH address, BIC/IBAN]
  Z -->|invalid or conflicting| R[REJECT in plain text<br/>archive to S3 archive/rejected]
  Z --> G[On-chain + liquidity check<br/>address on-chain, Circle balance, ledger deposits]
  G -->|unbacked or unreachable| R
  G -->|verified| D[Stamped PGL + CIS PDFs<br/>download]
  G --> M{Multi-rail governance}
  M -->|Ping| A[Manager approval]
  M -->|Access code| A
  M -->|Email OTP via MailerSend| A
  A -->|AMQP job| W[Settlement worker]
  W --> L[(Double-entry ledger<br/>Master_Treasury to Hot_Wallet)]
  W -->|Circle Mint transfer, idempotent| C[Circle API]
  C --> E[Personal ETH wallet<br/>USDC]
  W -->|Hot_Wallet to Recipient_Wallet| L
  W -.->|status fan-out| WS[WebSocket live status]
```

## Protocol selection matrix

| Concern | Protocol | Why | Status in this build |
|---|---|---|---|
| Claim intake, liquidity injection, approvals, downloads | **REST (HTTPS)** | Browser-friendly, multipart uploads, simple auth | Implemented |
| Settlement instruction (API to worker) | **gRPC** (contract in `proto/lsg.proto`) | Strong typing, deadlines, streaming status | Contract defined; carried over AMQP today |
| Settlement job queue, retries, dead-lettering | **AMQP / RabbitMQ** | Durable, at-least-once, DLQ, horizontal workers | Implemented (`lsg.settlements`, `lsg.settlements.dlq`) |
| Live status and manager pings | **WebSockets** (fed by an AMQP fan-out exchange `lsg.status`) | Push to every open browser | Implemented |

## Fail-closed rules

| Rule | Where enforced |
|---|---|
| Missing/invalid env, API key, KMS key, BIC or IBAN means the process exits | `config.ts`, `preflight.ts`, `ingest.ts` |
| Preflight verifies DB, S3 bucket, Ethereum RPC chain id, Circle credentials, RabbitMQ before serving | `preflight.ts` |
| Unbacked claim (Circle balance or Master_Treasury ledger too low) is rejected and files archived | `claims.ts` |
| Any verification service outage rejects the claim (never "assume OK") | `claims.ts` |
| Conflicting amounts/addresses across files, foreign currency, native ETH, multi-transaction files rejected | `ingest.ts` |
| Photo-read wallet addresses need valid EIP-55 checksum casing | `ingest.ts` |
| Duplicate document hashes cannot be paid twice | `claims.ts` |
| Everything re-verified immediately before money moves | `settlement.ts` |
| Ledger entries must balance at commit; ledger and audit tables are append-only | `db/schema.sql` |
| Uncertain Circle responses keep the same idempotency key and never create a second transfer | `settlement.ts`, `circle.ts` |
| Secrets, keys, OTPs, IBANs, 64-hex values are masked in logs, errors and audit records | `mask.ts` |

## Approval policy

| Action | Allowed rails |
|---|---|
| Initial approval | Ping, Access code, or Email OTP (set `REQUIRE_EMAIL_OTP_INITIAL=true` to require Email OTP) |
| Re-settlement (settled or failed claims) | **Email OTP only**, with a written reason (10+ characters) |

Only the manager role can answer a ping, enter an access code, or enter an email code. Operators can request challenges, but the code goes to the manager's inbox.

## Daily tranches

A claim may be up to `MAX_PAYOUT_USDC` (default 1 trillion). One manager approval covers the whole claim. Each UTC day the worker pays `min(remaining, daily tranche cap, lifetime room)` (default 1 billion), re-verifying the destination and the live Circle balance before every tranche, and the claim shows `tranching` between days. A failed tranche is reversed in the ledger and the claim stops as `failed`; the unpaid remainder needs a re-settlement with an Email OTP. There is no auto-approval: nothing is paid until a manager approves. Re-settlement (Email OTP + written reason) works on `failed` claims (pays the unpaid remainder) and on `settled` claims (the full amount becomes payable again, capped by the per-claim maximum and the daily/total limits).

## Ledger

Accounts: `EXTERNAL_DEPOSITS`, `MASTER_TREASURY`, `HOT_WALLET`, `RECIPIENT:<address>`. Balance = debits - credits.

| Event | Debit | Credit |
|---|---|---|
| Liquidity injection (proven on-chain) | MASTER_TREASURY | EXTERNAL_DEPOSITS |
| Reserve for settlement | HOT_WALLET | MASTER_TREASURY |
| Circle transfer complete | RECIPIENT:<address> | HOT_WALLET |
| Circle transfer failed (reversal) | MASTER_TREASURY | HOT_WALLET |

## Deployment

`Dockerfile` (one image, API or worker via command), `docker-compose.yml` (local stack), `k8s/lsg.yaml` (namespace, IRSA service account, API + worker deployments, ingress with WebSocket timeouts, network policy, HPA). Use managed Postgres and RabbitMQ in production. Inject secrets from a secret manager into `lsg-secrets`.
