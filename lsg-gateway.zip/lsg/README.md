# Liquidity Settlement Gateway (LSG)

Upload invoices, ISO 20022 files, PDFs or photos. The app reads the amount, wallet and bank identifiers from them, verifies funding live, issues stamped PGL and CIS PDFs, waits for manager approval on one of three rails, then pays **USDC on Ethereum** to the recipient's personal wallet through **Circle Mint**. It records every move in a double-entry ledger.

## Run it

```bash
cp .env.example .env            # fill every value; the app refuses to start otherwise
npm run hash-pin -- <access-code>   # paste the output line into .env (MANAGER_PIN_HASH)
export POSTGRES_PASSWORD=... RABBITMQ_PASSWORD=...   # also reflect them in DATABASE_URL / AMQP_URL
docker compose up --build
# open http://localhost:8080, sign in with OPERATOR_TOKEN or MANAGER_TOKEN
```

First fund the treasury: send USDC to your Circle Mint deposit address (`TREASURY_ETH_ADDRESS`), then use **Inject liquidity** with the transaction hash. Until the deposit is proven on-chain, Master_Treasury is empty and every claim is rejected as unbacked.

## Using it

1. **Submit documents.** Add files or photos, type your name, draw your signature, tick the declaration, and press Submit.
2. **Verified:** you get the extracted amount, asset and wallet, plus **Download PGL** and **Download CIS** (stamped, with your name and signature).
3. **Rejected:** you get a plain-text reason; every file is archived under `archive/rejected/` in S3.
4. **Approval (manager):** Ping (push to the manager's open session), access code, or an email code via MailerSend. The payout starts right after approval.
5. **Re-settlement:** settled or failed claims can be paid again only with a written reason and an Email OTP.

## Layout

| Path | Purpose |
|---|---|
| `src/config.ts`, `preflight.ts` | Fail-closed configuration and startup checks |
| `src/extract.ts`, `ingest.ts` | Read files (XML, JSON, PDF text, OCR) and validate with Zod |
| `src/claims.ts` | S3 intake, verification gate, archive or promote, stamped PDFs |
| `src/pdf.ts` | PGL / CIS generation with signature and HMAC stamp |
| `src/governance.ts` | Ping, access-code and Email-OTP rails |
| `src/settlement.ts`, `circle.ts`, `ledger.ts` | Reserve, pay via Circle, reconcile, double-entry ledger |
| `src/server.ts`, `worker.ts`, `queue.ts` | REST + WebSocket API, AMQP worker |
| `db/schema.sql` | Postgres schema (append-only ledger and audit) |
| `docs/ARCHITECTURE.md`, `proto/`, `schemas/`, `k8s/` | Diagram, protocol matrix, contracts, deployment |

## Things to know before real money

* **Circle pays USDC, not native ETH.** Amounts must be stated in USD/USDC; files that ask for ETH are rejected.
* **The stamp is an HMAC seal from this gateway**, verifiable at `GET /api/verify/<stamp>`. It is not a bank, notary or PKI signature, and the PGL says so. For a legally binding signature, sign with a KMS asymmetric key or a qualified e-signature provider.
* **"PGL" and "CIS"** are implemented as *Payment Guarantee Letter* and *Counterparty Information Sheet*. Tell me if your templates mean something else.
* **Circle recipient-address calls** (`/v1/businessAccount/wallets/addresses/recipient`, `/balances`) follow Circle's Mint API but were not testable here. Check them against your account in Circle's sandbox first.
* **OCR is fallible.** Wallet addresses read from photos must have a valid EIP-55 checksum, files must agree with each other, and the manager sees the full address (and can open the originals) before approving.
* **Ping rail** pushes to the manager's open browser session (and to an optional ntfy topic). Hardware-key (WebAuthn) approval is not built.
* Run in Circle **sandbox** with a testnet chain (`CIRCLE_BASE_URL=https://api-sandbox.circle.com`, matching `CHAIN_ID`) before pointing at production.
