-- Liquidity Settlement Gateway schema. Idempotent: safe to run on every start.

CREATE TABLE IF NOT EXISTS claims (
  id               uuid PRIMARY KEY,
  status           text NOT NULL CHECK (status IN
                     ('rejected','awaiting_approval','approved','settling','tranching','settled','failed')),
  amount           numeric(38,6) CHECK (amount > 0),
  asset            text CHECK (asset = 'USDC'),
  network          text CHECK (network = 'ETH'),
  destination      text,
  source_kind      text,
  metadata         jsonb NOT NULL DEFAULT '{}',
  rejection_reason text,
  created_by       text NOT NULL,
  settlement_count int  NOT NULL DEFAULT 0,
  next_tranche_at  timestamptz,
  payable_amount   numeric(38,6), -- amount + approved re-settlements of already-paid claims; NULL = amount
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS claim_files (
  id            uuid PRIMARY KEY,
  claim_id      uuid NOT NULL REFERENCES claims(id),
  kind          text NOT NULL CHECK (kind IN ('upload','signature','pgl','cis')),
  s3_key        text NOT NULL,
  original_name text NOT NULL,
  mime          text NOT NULL,
  size_bytes    bigint NOT NULL,
  sha256        text NOT NULL,
  archived      boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS claim_files_claim ON claim_files(claim_id);

CREATE TABLE IF NOT EXISTS challenges (
  id          uuid PRIMARY KEY,
  claim_id    uuid NOT NULL REFERENCES claims(id),
  rail        text NOT NULL CHECK (rail IN ('ping','email')),
  purpose     text NOT NULL CHECK (purpose IN ('initial','resettle')),
  code_hmac   text,
  reason      text,
  status      text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','denied','consumed','expired')),
  attempts    int  NOT NULL DEFAULT 0,
  expires_at  timestamptz NOT NULL,
  created_by  text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS approvals (
  id         uuid PRIMARY KEY,
  claim_id   uuid NOT NULL REFERENCES claims(id),
  purpose    text NOT NULL,
  rail       text NOT NULL CHECK (rail IN ('ping','pin','email')),
  approver   text NOT NULL,
  reason     text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settlements (
  id                uuid PRIMARY KEY,
  claim_id          uuid NOT NULL REFERENCES claims(id),
  attempt           int  NOT NULL,
  idempotency_key   uuid NOT NULL,
  amount            numeric(38,6) NOT NULL,
  destination       text NOT NULL,
  status            text NOT NULL CHECK (status IN ('reserved','submitted','complete','failed')),
  circle_address_id text,
  circle_transfer_id text,
  tx_hash           text,
  error             text,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (claim_id, attempt)
);

-- ===== Double-entry ledger (balance = SUM(debit) - SUM(credit)) =====
CREATE TABLE IF NOT EXISTS accounts (
  id   text PRIMARY KEY,
  kind text NOT NULL
);
INSERT INTO accounts(id, kind) VALUES
  ('EXTERNAL_DEPOSITS','external'),
  ('MASTER_TREASURY','treasury'),
  ('HOT_WALLET','hot')
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS journal_entries (
  id         uuid PRIMARY KEY,
  claim_id   uuid REFERENCES claims(id),
  kind       text NOT NULL,
  memo       text NOT NULL,
  ref        text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ledger_lines (
  id         bigserial PRIMARY KEY,
  entry_id   uuid NOT NULL REFERENCES journal_entries(id),
  account_id text NOT NULL REFERENCES accounts(id),
  debit      numeric(38,6) NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit     numeric(38,6) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  CHECK ((debit = 0) <> (credit = 0))
);
CREATE INDEX IF NOT EXISTS ledger_lines_account ON ledger_lines(account_id);

CREATE TABLE IF NOT EXISTS onchain_deposits (
  tx_hash    text NOT NULL,
  log_index  int  NOT NULL,
  amount     numeric(38,6) NOT NULL,
  from_addr  text NOT NULL,
  entry_id   uuid NOT NULL REFERENCES journal_entries(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tx_hash, log_index)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id       bigserial PRIMARY KEY,
  ts       timestamptz NOT NULL DEFAULT now(),
  actor    text NOT NULL,
  action   text NOT NULL,
  claim_id uuid,
  detail   jsonb NOT NULL DEFAULT '{}'
);

-- Every journal entry must balance at commit time.
CREATE OR REPLACE FUNCTION assert_entry_balanced() RETURNS trigger AS $$
DECLARE d numeric; c numeric;
BEGIN
  SELECT COALESCE(SUM(debit),0), COALESCE(SUM(credit),0) INTO d, c FROM ledger_lines WHERE entry_id = NEW.entry_id;
  IF d <> c THEN RAISE EXCEPTION 'unbalanced journal entry % (debit %, credit %)', NEW.entry_id, d, c; END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_entry_balanced ON ledger_lines;
CREATE CONSTRAINT TRIGGER trg_entry_balanced AFTER INSERT ON ledger_lines
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION assert_entry_balanced();

-- Ledger and audit are append-only.
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION 'table % is append-only', TG_TABLE_NAME; END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_lines_immutable ON ledger_lines;
CREATE TRIGGER trg_lines_immutable BEFORE UPDATE OR DELETE ON ledger_lines FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
DROP TRIGGER IF EXISTS trg_journal_immutable ON journal_entries;
CREATE TRIGGER trg_journal_immutable BEFORE UPDATE OR DELETE ON journal_entries FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
DROP TRIGGER IF EXISTS trg_audit_immutable ON audit_log;
CREATE TRIGGER trg_audit_immutable BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

CREATE TABLE IF NOT EXISTS recipients (
  address           text PRIMARY KEY,
  circle_address_id text NOT NULL,
  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stamps (
  stamp        text PRIMARY KEY,
  claim_id     uuid NOT NULL REFERENCES claims(id),
  kind         text NOT NULL CHECK (kind IN ('pgl','cis')),
  payload_sha256 text NOT NULL,
  pdf_sha256   text NOT NULL,
  signer_name  text NOT NULL,
  issued_at    timestamptz NOT NULL DEFAULT now()
);
