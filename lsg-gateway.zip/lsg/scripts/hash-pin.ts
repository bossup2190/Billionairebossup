// Usage: npm run hash-pin -- <access-code>   ->  prints MANAGER_PIN_HASH value (scrypt salt:hash)
import crypto from 'node:crypto';

const pin = process.argv[2];
if (!pin || pin.length < 6) {
  console.error('Provide an access code of at least 6 characters: npm run hash-pin -- <code>');
  process.exit(1);
}
const salt = crypto.randomBytes(16);
const hash = crypto.scryptSync(pin, salt, 32);
process.stdout.write(`MANAGER_PIN_HASH=${salt.toString('hex')}:${hash.toString('hex')}\n`);
