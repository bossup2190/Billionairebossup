import crypto from 'node:crypto';
import { config } from './config.js';
import { pool, tx, audit } from './db.js';
import { putObject, moveObject, safeName } from './s3.js';
import { extractText } from './extract.js';
import { deriveClaim, type ClaimMeta, type InputDoc } from './ingest.js';
import { validateDestination } from './chain.js';
import { availableUsd } from './circle.js';
import { hasAtLeast, TREASURY } from './ledger.js';
import { micro, isCentPrecise } from './money.js';
import { buildStampedPdf, type DocKind } from './pdf.js';
import { publishStatus } from './queue.js';
import { log } from './mask.js';

export interface Upload {
  name: string;
  mime: string;
  buf: Buffer;
}

export type ProcessResult =
  | { ok: true; claimId: string; meta: ClaimMeta; documents: DocKind[] }
  | { ok: false; claimId: string; reason: string };

interface Stored {
  kind: 'upload' | 'signature';
  name: string;
  mime: string;
  size: number;
  sha256: string;
  key: string;
}

const sha = (b: Buffer) => crypto.createHash('sha256').update(b).digest('hex');
const maskIban = (v: string) => `${'*'.repeat(Math.max(0, v.length - 4))}${v.slice(-4)}`;

/** The fail-closed gate: live verification against Circle, the ledger and the chain. */
async function verifyGate(meta: ClaimMeta, hashes: string[]): Promise<{ ok: true; checks: string[] } | { ok: false; reason: string }> {
  try {
    const checks: string[] = [];
    if (micro(meta.amount) > micro(String(config.MAX_PAYOUT_USDC)))
      return { ok: false, reason: `Amount ${meta.amount} USDC exceeds the per-payout limit of ${config.MAX_PAYOUT_USDC} USDC.` };
    if (!isCentPrecise(meta.amount)) return { ok: false, reason: 'Amount has more than 2 decimal places; Circle USD transfers are cent-denominated.' };
    checks.push('Amount within per-payout limit and cent-precise');

    const dup = await pool.query(
      `SELECT DISTINCT f.claim_id FROM claim_files f JOIN claims c ON c.id = f.claim_id
        WHERE f.kind = 'upload' AND f.sha256 = ANY($1) AND c.status <> 'rejected' LIMIT 1`,
      [hashes],
    );
    if (dup.rowCount) return { ok: false, reason: `A submitted file was already used in claim ${dup.rows[0].claim_id}. Duplicate documents cannot be paid twice.` };
    checks.push('No duplicate documents');

    const dest = await validateDestination(meta.destination);
    if (!dest.ok) return { ok: false, reason: dest.reason };
    checks.push('Destination is a valid personal (non-contract) Ethereum wallet, confirmed on-chain');

    const circleBal = await availableUsd();
    if (micro(circleBal) < micro(meta.amount))
      return { ok: false, reason: `UNBACKED CLAIM: requested ${meta.amount} USDC but the settlement account does not hold enough available funds.` };
    checks.push('Live settlement-account balance covers the amount');

    if (!(await hasAtLeast(pool, TREASURY, meta.amount)))
      return { ok: false, reason: `UNBACKED CLAIM: requested ${meta.amount} USDC exceeds verified Master_Treasury ledger deposits.` };
    checks.push('Verified ledger deposits (Master_Treasury) cover the amount');
    return { ok: true, checks };
  } catch (e) {
    log.error('verification gate error', e);
    return { ok: false, reason: 'Verification could not be completed (a required service was unreachable). Failing closed; nothing was settled.' };
  }
}

export async function processClaim(p: { uploads: Upload[]; signerName: string; signaturePng: Buffer; actor: string }): Promise<ProcessResult> {
  const claimId = crypto.randomUUID();
  const signedAt = new Date();

  // 1. S3 intake (SSE-KMS). Nothing is trusted until verified.
  const stored: Stored[] = [];
  for (const [i, u] of p.uploads.entries()) {
    const s: Stored = { kind: 'upload', name: u.name, mime: u.mime, size: u.buf.length, sha256: sha(u.buf), key: `intake/${claimId}/${i}-${safeName(u.name)}` };
    await putObject(s.key, u.buf, u.mime, s.sha256);
    stored.push(s);
  }
  const sigStored: Stored = { kind: 'signature', name: 'signature.png', mime: 'image/png', size: p.signaturePng.length, sha256: sha(p.signaturePng), key: `intake/${claimId}/signature.png` };
  await putObject(sigStored.key, p.signaturePng, 'image/png', sigStored.sha256);
  stored.push(sigStored);

  // 2. Extract + validate (Zod).
  const docs: InputDoc[] = [];
  for (const [i, u] of p.uploads.entries()) docs.push({ ...(await extractText(u.buf, u.mime, u.name)), name: stored[i].name });
  const derived = deriveClaim(docs);

  // 3. Fail-closed gate.
  const hashes = stored.filter((s) => s.kind === 'upload').map((s) => s.sha256);
  const gate = derived.ok ? await verifyGate(derived.meta, hashes) : { ok: false as const, reason: derived.reason };

  if (!derived.ok || !gate.ok) {
    const reason = !derived.ok ? derived.reason : (gate as { reason: string }).reason;
    // Hard stop: archive every file for audit, record the rejection.
    const rows: Array<Stored & { archivedKey: string }> = [];
    for (const s of stored) {
      const archivedKey = s.key.replace(/^intake\//, 'archive/rejected/');
      await moveObject(s.key, archivedKey);
      rows.push({ ...s, archivedKey });
    }
    await tx(async (c) => {
      await c.query("INSERT INTO claims(id, status, rejection_reason, created_by, metadata) VALUES ($1,'rejected',$2,$3,$4)", [
        claimId,
        reason,
        p.actor,
        JSON.stringify({ signer: { name: p.signerName, signedAt } }),
      ]);
      for (const r of rows)
        await c.query(
          'INSERT INTO claim_files(id, claim_id, kind, s3_key, original_name, mime, size_bytes, sha256, archived) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,true)',
          [crypto.randomUUID(), claimId, r.kind, r.archivedKey, r.name, r.mime, r.size, r.sha256],
        );
      await audit(c, p.actor, 'claim_rejected', claimId, { reason });
    });
    await publishStatus({ type: 'claim', claimId, status: 'rejected' });
    return { ok: false, claimId, reason };
  }

  // 4. Verified: promote files, issue stamped PGL + CIS.
  const meta = derived.meta;
  const verifiedAt = new Date();
  const rows: Array<Stored & { finalKey: string }> = [];
  for (const s of stored) {
    const finalKey = s.key.replace(/^intake\//, 'verified/');
    await moveObject(s.key, finalKey);
    rows.push({ ...s, finalKey });
  }
  const generated: Array<{ kind: DocKind; key: string; size: number; sha256: string; stamp: string; payloadSha256: string }> = [];
  for (const kind of ['pgl', 'cis'] as const) {
    const doc = await buildStampedPdf({
      claimId,
      kind,
      amount: meta.amount,
      destination: meta.destination,
      sourceKind: meta.sourceKind,
      debtorBic: meta.debtorBic,
      debtorIban: meta.debtorIban,
      files: stored.filter((s) => s.kind === 'upload').map((s) => ({ name: s.name, sha256: s.sha256 })),
      provenance: meta.provenance,
      checks: gate.checks,
      signerName: p.signerName,
      signedAt,
      signaturePng: p.signaturePng,
      verifiedAt,
    });
    const key = `generated/${claimId}/${kind.toUpperCase()}-${claimId}.pdf`;
    await putObject(key, doc.pdf, 'application/pdf', doc.pdfSha256);
    generated.push({ kind, key, size: doc.pdf.length, sha256: doc.pdfSha256, stamp: doc.stamp, payloadSha256: doc.payloadSha256 });
  }

  await tx(async (c) => {
    await c.query(
      `INSERT INTO claims(id, status, amount, asset, network, destination, source_kind, metadata, created_by)
       VALUES ($1,'awaiting_approval',$2,'USDC','ETH',$3,$4,$5,$6)`,
      [
        claimId,
        meta.amount,
        meta.destination,
        meta.sourceKind,
        JSON.stringify({ ...meta, debtorIban: meta.debtorIban ? maskIban(meta.debtorIban) : undefined, checks: gate.checks, signer: { name: p.signerName, signedAt } }),
        p.actor,
      ],
    );
    for (const r of rows)
      await c.query(
        'INSERT INTO claim_files(id, claim_id, kind, s3_key, original_name, mime, size_bytes, sha256) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
        [crypto.randomUUID(), claimId, r.kind, r.finalKey, r.name, r.mime, r.size, r.sha256],
      );
    for (const g of generated) {
      await c.query(
        'INSERT INTO claim_files(id, claim_id, kind, s3_key, original_name, mime, size_bytes, sha256) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
        [crypto.randomUUID(), claimId, g.kind, g.key, `${g.kind.toUpperCase()}-${claimId}.pdf`, 'application/pdf', g.size, g.sha256],
      );
      await c.query('INSERT INTO stamps(stamp, claim_id, kind, payload_sha256, pdf_sha256, signer_name) VALUES ($1,$2,$3,$4,$5,$6)', [
        g.stamp,
        claimId,
        g.kind,
        g.payloadSha256,
        g.sha256,
        p.signerName,
      ]);
    }
    await audit(c, p.actor, 'claim_verified', claimId, { amount: meta.amount, destination: meta.destination, stamps: generated.map((g) => g.stamp) });
  });
  await publishStatus({ type: 'claim', claimId, status: 'awaiting_approval' });
  return { ok: true, claimId, meta, documents: ['pgl', 'cis'] };
}
