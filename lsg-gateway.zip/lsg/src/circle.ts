import crypto from 'node:crypto';
import { config } from './config.js';
import { redactString } from './mask.js';

// Circle Mint (https://developers.circle.com/circle-mint). Payouts are USD-denominated transfers
// that Circle delivers as USDC to a verified blockchain recipient address on Ethereum.
export class CircleError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
  /** 4xx (other than 408/429) means Circle definitively refused the request. */
  get definitive(): boolean {
    return this.status >= 400 && this.status < 500 && this.status !== 408 && this.status !== 429;
  }
}

async function call<T>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
  const res = await fetch(config.CIRCLE_BASE_URL + path, {
    method,
    headers: { Authorization: `Bearer ${config.CIRCLE_API_KEY}`, 'Content-Type': 'application/json', Accept: 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(20_000),
  });
  const text = await res.text();
  if (!res.ok) throw new CircleError(res.status, `Circle ${method} ${path} failed (${res.status}): ${redactString(text.slice(0, 300))}`);
  return JSON.parse(text) as T;
}

/** Live available USD balance of the Circle Mint account. */
export async function availableUsd(): Promise<string> {
  const r = await call<{ data: { available?: Array<{ amount: string; currency: string }> } }>('GET', '/v1/businessAccount/balances');
  const usd = r.data.available?.find((b) => b.currency === 'USD');
  return usd?.amount ?? '0';
}

// Deterministic UUID-shaped key so repeated calls for one address can never create duplicates.
export function keyFor(seed: string): string {
  const h = crypto.createHash('sha256').update(seed).digest('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-8${h.slice(17, 20)}-${h.slice(20, 32)}`;
}

/** Register a recipient address with Circle (idempotent) and return its address id. */
export async function createRecipient(address: string): Promise<string> {
  const r = await call<{ data: { id: string } }>('POST', '/v1/businessAccount/wallets/addresses/recipient', {
    idempotencyKey: keyFor(`recipient:${address.toLowerCase()}`),
    address,
    chain: 'ETH',
    currency: 'USD',
    description: 'LSG payout recipient',
  });
  return r.data.id;
}

export interface CircleTransfer {
  id: string;
  status: string; // created | running | pending | complete | failed
  transactionHash?: string | null;
  errorCode?: string | null;
}

export async function createTransfer(p: { idempotencyKey: string; addressId: string; amount: string }): Promise<CircleTransfer> {
  const r = await call<{ data: CircleTransfer }>('POST', '/v1/businessAccount/transfers', {
    idempotencyKey: p.idempotencyKey,
    ...(config.CIRCLE_SOURCE_WALLET_ID ? { source: { type: 'wallet', id: config.CIRCLE_SOURCE_WALLET_ID } } : {}),
    destination: { type: 'verified_blockchain', addressId: p.addressId },
    amount: { amount: p.amount, currency: 'USD' },
  });
  return r.data;
}

export async function getTransfer(id: string): Promise<CircleTransfer> {
  return (await call<{ data: CircleTransfer }>('GET', `/v1/businessAccount/transfers/${encodeURIComponent(id)}`)).data;
}
