import { preflight } from './preflight.js';
import { consumeSettlements } from './queue.js';
import { runSettlement, reconcile } from './settlement.js';
import { pool } from './db.js';
import { log } from './mask.js';

async function main() {
  await preflight();
  await consumeSettlements(({ claimId }) => runSettlement(claimId));
  // Resume in-flight Circle transfers and re-enqueue approvals whose job was lost.
  const tick = () => reconcile().catch((e) => log.error('reconcile tick failed', e));
  setInterval(tick, 15_000);
  void tick();
  log.info('LSG settlement worker running');
  const stop = () => pool.end().finally(() => process.exit(0));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

process.on('unhandledRejection', (e) => {
  log.error('unhandledRejection; exiting (fail closed)', e);
  process.exit(1);
});
main().catch((e) => {
  log.error('FATAL worker startup failure', e);
  process.exit(1);
});
