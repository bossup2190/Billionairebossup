import http from 'node:http';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import multer from 'multer';
import { WebSocketServer, type WebSocket } from 'ws';
import { config } from './config.js';
import { log, redactString } from './mask.js';
import { pool, tx, audit } from './db.js';
import { preflight } from './preflight.js';
import { consumeStatus, type StatusEvent } from './queue.js';
import { requireRole, roleOf, type Role } from './auth.js';
import { processClaim } from './claims.js';
import { getObject } from './s3.js';
import { verifyDeposit, } from './chain.js';
import { availableUsd } from './circle.js';
import * as ledger from './ledger.js';
import { micro } from './money.js';
import { GovernanceError, requestChallenge, respondPing, approveWithEmail, approveWithPin } from './governance.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const bad = (res: Response, msg: string, status = 400) => res.status(status).type('text/plain').send(msg);
const wrap = (fn: (req: Request, res: Response) => Promise<unknown>) => (req: Request, res: Response, next: NextFunction) => fn(req, res).catch(next);
const uuidParam = (req: Request, name = 'id') => {
  const v = String(req.params[name]);
  if (!UUID.test(v)) throw new GovernanceError(400, `Invalid ${name}.`);
  return v;
};

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024, files: 10, fieldSize: 600 * 1024, fields: 8 } });

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws: wss:; frame-ancestors 'none'",
  );
  next();
});
app.use(express.json({ limit: '64kb' }));
app.use(express.static(path.resolve(process.cwd(), 'public')));

app.get('/healthz', (_req, res) => void res.type('text/plain').send('ok'));

app.get('/api/me', requireRole('operator'), (_req, res) => void res.json({ role: res.locals.role }));

// ---- Claim intake: upload files + signature, extract, verify, stamp ----
app.post(
  '/api/claims',
  requireRole('operator'),
  upload.array('files', 10),
  wrap(async (req, res) => {
    const files = (req.files as Express.Multer.File[] | undefined) ?? [];
    if (!files.length) return bad(res, 'Attach at least one file or photo.');
    const signerName = String(req.body.signerName ?? '').trim();
    if (signerName.length < 2 || signerName.length > 80) return bad(res, 'Enter your full name (2-80 characters).');
    const m = /^data:image\/png;base64,([A-Za-z0-9+/=]+)$/.exec(String(req.body.signature ?? ''));
    if (!m) return bad(res, 'A drawn signature is required.');
    const signaturePng = Buffer.from(m[1], 'base64');
    if (signaturePng.length < 200 || signaturePng.length > 400 * 1024 || signaturePng.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a')
      return bad(res, 'Signature image is invalid.');

    const result = await processClaim({
      uploads: files.map((f) => ({ name: f.originalname, mime: f.mimetype || 'application/octet-stream', buf: f.buffer })),
      signerName,
      signaturePng,
      actor: res.locals.actor,
    });
    if (!result.ok) {
      return res
        .status(422)
        .type('text/plain')
        .send(`CLAIM REJECTED\nClaim: ${result.claimId}\nReason: ${result.reason}\nAll submitted files were archived for audit. No funds were moved.`);
    }
    res.status(201).json({
      claimId: result.claimId,
      status: 'awaiting_approval',
      extracted: { amount: result.meta.amount, asset: 'USDC', network: 'Ethereum', destination: result.meta.destination, sourceKind: result.meta.sourceKind, provenance: result.meta.provenance },
      documents: result.documents,
    });
  }),
);

app.get('/api/claims', requireRole('operator'), wrap(async (_req, res) => {
  const r = await pool.query('SELECT id, status, amount, destination, source_kind, rejection_reason, created_at FROM claims ORDER BY created_at DESC LIMIT 50');
  res.json(r.rows);
}));

app.get('/api/claims/:id', requireRole('operator'), wrap(async (req, res) => {
  const id = uuidParam(req);
  const claim = (await pool.query('SELECT * FROM claims WHERE id=$1', [id])).rows[0];
  if (!claim) return bad(res, 'Claim not found.', 404);
  const [files, approvals, settlements, stamps] = await Promise.all([
    pool.query('SELECT id, kind, original_name, size_bytes, sha256, archived FROM claim_files WHERE claim_id=$1 ORDER BY created_at', [id]),
    pool.query('SELECT purpose, rail, approver, reason, created_at FROM approvals WHERE claim_id=$1 ORDER BY created_at', [id]),
    pool.query('SELECT attempt, status, tx_hash, error, created_at FROM settlements WHERE claim_id=$1 ORDER BY attempt', [id]),
    pool.query('SELECT stamp, kind, issued_at FROM stamps WHERE claim_id=$1', [id]),
  ]);
  res.json({ claim, files: files.rows, approvals: approvals.rows, settlements: settlements.rows, stamps: stamps.rows });
}));

const sendFile = async (res: Response, key: string, name: string, mime: string) => {
  const buf = await getObject(key);
  res.setHeader('Content-Type', mime);
  res.setHeader('Content-Disposition', `attachment; filename="${name.replace(/[^A-Za-z0-9._-]/g, '_')}"`);
  res.send(buf);
};

// Stamped PGL / CIS download (only exists for verified claims).
app.get('/api/claims/:id/documents/:kind', requireRole('operator'), wrap(async (req, res) => {
  const id = uuidParam(req);
  const kind = String(req.params.kind);
  if (kind !== 'pgl' && kind !== 'cis') return bad(res, 'Unknown document.', 404);
  const f = (await pool.query('SELECT s3_key, original_name FROM claim_files WHERE claim_id=$1 AND kind=$2', [id, kind])).rows[0];
  if (!f) return bad(res, 'No document: the claim was not verified.', 404);
  await audit(pool, res.locals.actor, 'document_downloaded', id, { kind });
  await sendFile(res, f.s3_key, f.original_name, 'application/pdf');
}));

// Managers can inspect the original submission before approving.
app.get('/api/claims/:id/files/:fileId', requireRole('manager'), wrap(async (req, res) => {
  const f = (await pool.query('SELECT s3_key, original_name FROM claim_files WHERE claim_id=$1 AND id=$2 AND kind IN (\'upload\',\'signature\')', [uuidParam(req), uuidParam(req, 'fileId')])).rows[0];
  if (!f) return bad(res, 'File not found.', 404);
  await sendFile(res, f.s3_key, f.original_name, 'application/octet-stream');
}));

// ---- Multi-rail governance ----
app.post('/api/claims/:id/challenge', requireRole('operator'), wrap(async (req, res) => {
  const { rail, purpose, reason } = req.body ?? {};
  if ((rail !== 'ping' && rail !== 'email') || (purpose !== 'initial' && purpose !== 'resettle')) return bad(res, 'Invalid rail or purpose.');
  res.status(201).json(await requestChallenge(uuidParam(req), rail, purpose, typeof reason === 'string' ? reason : undefined, res.locals.actor));
}));
app.post('/api/challenges/:id/respond', requireRole('manager'), wrap(async (req, res) => {
  const d = req.body?.decision;
  if (d !== 'approve' && d !== 'deny') return bad(res, 'decision must be approve or deny.');
  res.json(await respondPing(uuidParam(req), d, res.locals.actor));
}));
app.post('/api/claims/:id/approve/pin', requireRole('manager'), wrap(async (req, res) => {
  if (typeof req.body?.pin !== 'string' || req.body.pin.length < 4 || req.body.pin.length > 64) return bad(res, 'Enter your access code.');
  await approveWithPin(uuidParam(req), req.body.pin, res.locals.actor);
  res.json({ approved: true });
}));
app.post('/api/claims/:id/approve/email', requireRole('manager'), wrap(async (req, res) => {
  const { challengeId, code } = req.body ?? {};
  if (typeof challengeId !== 'string' || !UUID.test(challengeId) || typeof code !== 'string') return bad(res, 'challengeId and code are required.');
  await approveWithEmail(uuidParam(req), challengeId, code.trim(), res.locals.actor);
  res.json({ approved: true });
}));

// ---- Liquidity injection: credit Master_Treasury only after the deposit is proven on-chain ----
app.post('/api/liquidity/injections', requireRole('manager'), wrap(async (req, res) => {
  const txHash = String(req.body?.txHash ?? '');
  let deposits;
  try {
    deposits = await verifyDeposit(txHash);
  } catch (e) {
    return bad(res, `Injection rejected: ${(e as Error).message}`, 422);
  }
  const credited = await tx(async (c) => {
    let total = 0n;
    for (const d of deposits) {
      const entryRef = `inj:${txHash.toLowerCase()}:${d.logIndex}`;
      const posted = await ledger.postEntry(c, {
        kind: 'injection',
        memo: `On-chain USDC deposit ${txHash}`,
        ref: entryRef,
        lines: [{ account: ledger.TREASURY, debit: d.amount }, { account: ledger.EXTERNAL_DEPOSITS, credit: d.amount }],
      });
      if (!posted) continue;
      const id = (await c.query('SELECT id FROM journal_entries WHERE ref=$1', [entryRef])).rows[0].id;
      await c.query('INSERT INTO onchain_deposits(tx_hash, log_index, amount, from_addr, entry_id) VALUES ($1,$2,$3,$4,$5)', [txHash.toLowerCase(), d.logIndex, d.amount, d.from, id]);
      total += micro(d.amount);
    }
    await audit(c, res.locals.actor, 'liquidity_injected', null, { txHash, deposits: deposits.length });
    return total;
  });
  res.status(201).json({ credited: credited > 0n, deposits: deposits.map((d) => ({ amount: d.amount, from: d.from })) });
}));

app.get('/api/ledger', requireRole('operator'), wrap(async (_req, res) => {
  const [treasury, hot, circleUsd] = await Promise.all([ledger.balanceOf(pool, ledger.TREASURY), ledger.balanceOf(pool, ledger.HOT), availableUsd().catch(() => null)]);
  res.json({ masterTreasury: treasury, hotWallet: hot, settlementAccountAvailableUsd: circleUsd, treasuryDepositAddress: config.TREASURY_ETH_ADDRESS });
}));

// Public: confirm a stamp printed on a PGL/CIS is genuine.
app.get('/api/verify/:stamp', wrap(async (req, res) => {
  const stamp = String(req.params.stamp).toUpperCase();
  if (!/^[0-9A-F]{8}(-[0-9A-F]{8}){3}$/.test(stamp)) return bad(res, 'Malformed stamp.');
  const r = (await pool.query('SELECT claim_id, kind, signer_name, pdf_sha256, issued_at FROM stamps WHERE stamp=$1', [stamp])).rows[0];
  if (!r) return res.status(404).json({ valid: false });
  res.json({ valid: true, kind: r.kind, claimId: r.claim_id, signer: r.signer_name, pdfSha256: r.pdf_sha256, issuedAt: r.issued_at });
}));

// ---- Errors: never leak internals or credentials ----
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (err instanceof GovernanceError) return void res.status(err.status).type('text/plain').send(err.message);
  if (err instanceof multer.MulterError) return void res.status(400).type('text/plain').send(`Upload problem: ${err.message}`);
  log.error('unhandled error', err);
  res.status(500).type('text/plain').send('Internal error. Nothing was settled.');
});

// ---- WebSockets: live status + manager pings, fed by the RabbitMQ fan-out ----
function startSockets(server: http.Server) {
  const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 4096 });
  const roles = new WeakMap<WebSocket, Role>();
  wss.on('connection', (ws) => {
    const timer = setTimeout(() => ws.close(4401, 'auth timeout'), 5000);
    ws.on('message', (raw) => {
      try {
        const m = JSON.parse(raw.toString());
        const role = m?.type === 'auth' ? roleOf(m.token) : null;
        if (!role) return void ws.close(4401, 'unauthorized');
        clearTimeout(timer);
        roles.set(ws, role);
        ws.send(JSON.stringify({ type: 'hello', role }));
      } catch {
        ws.close(4400, 'bad message');
      }
    });
    ws.on('close', () => clearTimeout(timer));
  });
  return (evt: StatusEvent) => {
    const msg = JSON.stringify(evt);
    for (const ws of wss.clients) {
      const role = roles.get(ws);
      if (!role || ws.readyState !== ws.OPEN) continue;
      if (evt.type === 'ping' && role !== 'manager') continue;
      ws.send(msg);
    }
  };
}

async function main() {
  await preflight();
  const server = http.createServer(app);
  const broadcast = startSockets(server);
  await consumeStatus(broadcast);
  server.listen(config.PORT, () => log.info(`LSG API listening on :${config.PORT}`));
  const stop = () => server.close(() => pool.end().finally(() => process.exit(0)));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

process.on('unhandledRejection', (e) => {
  log.error('unhandledRejection; exiting (fail closed)', e);
  process.exit(1);
});
main().catch((e) => {
  process.stderr.write(redactString(`FATAL: ${(e as Error).message}\n`));
  process.exit(1);
});
