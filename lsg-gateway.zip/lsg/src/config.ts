import { z } from 'zod';
import { registerSecret } from './mask.js';

const bool = z.enum(['true', 'false']).default('false').transform((v) => v === 'true');

const Env = z.object({
  PORT: z.coerce.number().int().default(8080),
  DATABASE_URL: z.string().min(1),
  AMQP_URL: z.string().min(1),

  AWS_REGION: z.string().min(1),
  S3_BUCKET: z.string().min(1),
  S3_KMS_KEY_ID: z.string().min(1),

  CIRCLE_API_KEY: z.string().min(20),
  CIRCLE_BASE_URL: z.string().url().default('https://api.circle.com'),
  CIRCLE_SOURCE_WALLET_ID: z.string().optional(),

  MAILERSEND_API_KEY: z.string().min(10),
  MAILERSEND_FROM_EMAIL: z.string().email(),
  MAILERSEND_FROM_NAME: z.string().default('LSG Governance'),

  ETH_RPC_URL: z.string().url(),
  CHAIN_ID: z.coerce.number().int().default(1),
  USDC_CONTRACT: z.string().regex(/^0x[a-fA-F0-9]{40}$/).default('0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48'),
  // The on-chain deposit address of the Circle Mint account (Master_Treasury funding address).
  TREASURY_ETH_ADDRESS: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  MIN_CONFIRMATIONS: z.coerce.number().int().min(1).default(12),

  OPERATOR_TOKEN: z.string().min(32),
  MANAGER_TOKEN: z.string().min(32),
  MANAGER_EMAIL: z.string().email(),
  // scrypt "salt:hash" (scripts/hash-pin.ts) or PBKDF2 "pbkdf2$iterations$salt$hash" (tools/setup.html)
  MANAGER_PIN_HASH: z.string().regex(/^([0-9a-f]+:[0-9a-f]+|pbkdf2\$\d+\$[0-9a-f]+\$[0-9a-f]+)$/),
  DOC_SIGNING_SECRET: z.string().min(32),

  MAX_PAYOUT_USDC: z.coerce.number().positive(), // per claim
  DAILY_PAYOUT_CAP_USDC: z.coerce.number().positive(), // per UTC day, across all claims ("daily tranche")
  TOTAL_PAYOUT_CAP_USDC: z.coerce.number().positive(), // lifetime ceiling
  REQUIRE_EMAIL_OTP_INITIAL: bool,
  ALLOW_CONTRACT_DESTINATIONS: bool,
  NTFY_TOPIC_URL: z.string().url().optional(),
});

export type Config = z.infer<typeof Env>;

function load(): Config {
  const parsed = Env.safeParse(process.env);
  if (!parsed.success) {
    // Fail closed. Print variable names only, never values.
    const names = [...new Set(parsed.error.issues.map((i) => i.path.join('.')))].join(', ');
    process.stderr.write(`FATAL: missing or invalid configuration: ${names}\nExecution halted.\n`);
    process.exit(1);
  }
  const c = parsed.data;
  for (const s of [c.CIRCLE_API_KEY, c.MAILERSEND_API_KEY, c.OPERATOR_TOKEN, c.MANAGER_TOKEN, c.MANAGER_PIN_HASH, c.DOC_SIGNING_SECRET, c.DATABASE_URL, c.AMQP_URL, c.ETH_RPC_URL])
    registerSecret(s);
  return c;
}

export const config = load();
