import {
  S3Client,
  PutObjectCommand,
  CopyObjectCommand,
  DeleteObjectCommand,
  GetObjectCommand,
  HeadBucketCommand,
} from '@aws-sdk/client-s3';
import { config } from './config.js';

// Credentials come from the default AWS chain (IRSA / instance role / env). Nothing is hard-coded.
const s3 = new S3Client({ region: config.AWS_REGION });
const Bucket = config.S3_BUCKET;
const kms = { ServerSideEncryption: 'aws:kms' as const, SSEKMSKeyId: config.S3_KMS_KEY_ID };

export function safeName(name: string): string {
  return name.replace(/[^A-Za-z0-9._-]/g, '_').slice(-100) || 'file';
}

export async function putObject(key: string, body: Buffer, contentType: string, sha256Hex: string): Promise<void> {
  await s3.send(
    new PutObjectCommand({
      Bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
      ChecksumSHA256: Buffer.from(sha256Hex, 'hex').toString('base64'),
      ...kms,
    }),
  );
}

export async function moveObject(from: string, to: string): Promise<void> {
  const src = `${Bucket}/${from.split('/').map(encodeURIComponent).join('/')}`;
  await s3.send(new CopyObjectCommand({ Bucket, Key: to, CopySource: src, ...kms }));
  await s3.send(new DeleteObjectCommand({ Bucket, Key: from }));
}

export async function getObject(key: string): Promise<Buffer> {
  const r = await s3.send(new GetObjectCommand({ Bucket, Key: key }));
  const bytes = await r.Body!.transformToByteArray();
  return Buffer.from(bytes);
}

export async function s3Preflight(): Promise<void> {
  await s3.send(new HeadBucketCommand({ Bucket }));
}
