import crypto from 'node:crypto';
import type { PoolClient } from 'pg';

export const TREASURY = 'MASTER_TREASURY';
export const HOT = 'HOT_WALLET';
export const EXTERNAL_DEPOSITS = 'EXTERNAL_DEPOSITS';
export const recipientAccount = (addr: string) => `RECIPIENT:${addr.toLowerCase()}`;

export interface Line {
  account: string;
  debit?: string;
  credit?: string;
}

/**
 * Post one balanced journal entry. Returns false when `ref` was already posted (idempotent replay).
 * Balance is enforced by a deferred DB constraint trigger, so an unbalanced entry cannot commit.
 */
export async function postEntry(
  c: PoolClient,
  e: { claimId?: string | null; kind: string; memo: string; ref: string; lines: Line[] },
): Promise<boolean> {
  const id = crypto.randomUUID();
  const ins = await c.query(
    'INSERT INTO journal_entries(id, claim_id, kind, memo, ref) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (ref) DO NOTHING RETURNING id',
    [id, e.claimId ?? null, e.kind, e.memo, e.ref],
  );
  if (!ins.rowCount) return false;
  for (const l of e.lines) {
    if (l.account.startsWith('RECIPIENT:'))
      await c.query("INSERT INTO accounts(id, kind) VALUES ($1,'recipient') ON CONFLICT DO NOTHING", [l.account]);
    await c.query('INSERT INTO ledger_lines(entry_id, account_id, debit, credit) VALUES ($1,$2,$3,$4)', [
      id,
      l.account,
      l.debit ?? '0',
      l.credit ?? '0',
    ]);
  }
  return true;
}

/** Move `amount` from one account to another (debit destination, credit source). */
export function move(
  c: PoolClient,
  p: { claimId?: string | null; kind: string; memo: string; ref: string; from: string; to: string; amount: string },
): Promise<boolean> {
  return postEntry(c, {
    claimId: p.claimId,
    kind: p.kind,
    memo: p.memo,
    ref: p.ref,
    lines: [
      { account: p.to, debit: p.amount },
      { account: p.from, credit: p.amount },
    ],
  });
}

export async function balanceOf(c: Pick<PoolClient, 'query'>, account: string): Promise<string> {
  const r = await c.query('SELECT COALESCE(SUM(debit) - SUM(credit), 0)::text AS bal FROM ledger_lines WHERE account_id = $1', [account]);
  return r.rows[0].bal;
}

/** Serialise concurrent spenders of one account. */
export async function lockAccount(c: PoolClient, account: string): Promise<void> {
  await c.query('SELECT id FROM accounts WHERE id = $1 FOR UPDATE', [account]);
}

export async function hasAtLeast(c: Pick<PoolClient, 'query'>, account: string, amount: string): Promise<boolean> {
  const r = await c.query('SELECT (COALESCE(SUM(debit) - SUM(credit), 0) >= $2::numeric) AS ok FROM ledger_lines WHERE account_id = $1', [account, amount]);
  return r.rows[0].ok === true;
}
