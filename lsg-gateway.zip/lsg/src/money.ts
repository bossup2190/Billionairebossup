// Decimal-string money helpers (no floating point anywhere near amounts).
export const micro = (s: string): bigint => {
  const [i, f = ''] = s.split('.');
  return BigInt(i) * 1_000_000n + BigInt((f + '000000').slice(0, 6));
};

/** At most 2 decimal places? (Circle USD transfers are cent-denominated.) */
export const isCentPrecise = (s: string): boolean => micro(s) % 10_000n === 0n;

/** Format as Circle expects: plain decimal string with 2 places. */
export const fmt2 = (s: string): string => {
  const [i, f = ''] = s.split('.');
  return `${BigInt(i).toString()}.${(f + '00').slice(0, 2)}`;
};

/** Inverse of micro(): bigint micro-units to a 6-dp decimal string. */
export const fromMicro = (n: bigint): string => {
  const neg = n < 0n;
  const a = neg ? -n : n;
  return `${neg ? '-' : ''}${(a / 1_000_000n).toString()}.${(a % 1_000_000n).toString().padStart(6, '0')}`;
};
