import { migrate, pool } from './db.js';
import { s3Preflight } from './s3.js';
import { chainPreflight } from './chain.js';
import { availableUsd } from './circle.js';
import { connectQueue } from './queue.js';
import { log } from './mask.js';

/**
 * Fail-closed startup: every dependency must be reachable and every credential valid,
 * otherwise the process exits before accepting any work.
 */
export async function preflight(): Promise<void> {
  const steps: Array<[string, () => Promise<unknown>]> = [
    ['database', async () => (await migrate(), pool.query('SELECT 1'))],
    ['s3 bucket + kms', s3Preflight],
    ['ethereum rpc', chainPreflight],
    ['circle credentials', availableUsd],
    ['rabbitmq', connectQueue],
  ];
  for (const [name, fn] of steps) {
    try {
      await fn();
      log.info(`preflight ok: ${name}`);
    } catch (e) {
      log.error(`FATAL preflight failed: ${name}. Execution halted.`, e);
      process.exit(1);
    }
  }
}
