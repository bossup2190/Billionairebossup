import crypto from 'node:crypto';
import type { PoolClient } from 'pg';
import { config } from './config.js';
import { pool, tx, audit } from './db.js';
import { sendOtpEmail } from './mailer.js';
import { publishSettlement, publishStatus } from './queue.js';
import { verifyPin } from './auth.js';
import { log } from './mask.js';

export class GovernanceError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export type Rail = 'ping' | 'pin' | 'email';
export type Purpose = 'initial' | 'resettle';

const OTP_TTL_MS = 10 * 60_000;
const PING_TTL_MS = 5 * 60_000;
const MAX_OTP_ATTEMPTS = 5;

const otpMac = (id: string, code: string) => crypto.createHmac('sha256', config.DOC_SIGNING_SECRET).update(`otp|${id}|${code}`).digest('hex');

async function loadClaim(id: string) {
  const r = await pool.query('SELECT id, status, amount, destination FROM claims WHERE id = $1', [id]);
  if (!r.rowCount) throw new GovernanceError(404, 'Claim not found.');
  return r.rows[0] as { id: string; status: string; amount: string; destination: string };
}

function assertState(status: string, purpose: Purpose) {
  if (purpose === 'initial' && status !== 'awaiting_approval') throw new GovernanceError(409, `Claim is ${status}; it is not awaiting approval.`);
  if (purpose === 'resettle' && status !== 'failed' && status !== 'settled') throw new GovernanceError(409, `Claim is ${status}; only failed or settled claims can be re-settled.`);
}

/** Request a ping (push) or Email-OTP challenge for a claim. */
export async function requestChallenge(claimId: string, rail: 'ping' | 'email', purpose: Purpose, reason: string | undefined, actor: string) {
  const claim = await loadClaim(claimId);
  assertState(claim.status, purpose);
  if (purpose === 'resettle') {
    if (rail !== 'email') throw new GovernanceError(403, 'Re-settlements require the Email OTP rail.');
    if (!reason || reason.trim().length < 10) throw new GovernanceError(400, 'A re-settlement reason of at least 10 characters is required.');
  }
  if (purpose === 'initial' && config.REQUIRE_EMAIL_OTP_INITIAL && rail !== 'email')
    throw new GovernanceError(403, 'Policy requires the Email OTP rail for initial approval.');

  await pool.query("UPDATE challenges SET status='expired' WHERE claim_id=$1 AND rail=$2 AND status='pending'", [claimId, rail]);
  const id = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + (rail === 'email' ? OTP_TTL_MS : PING_TTL_MS));
  let code: string | undefined;
  if (rail === 'email') code = String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');

  await pool.query(
    'INSERT INTO challenges(id, claim_id, rail, purpose, code_hmac, reason, expires_at, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [id, claimId, rail, purpose, code ? otpMac(id, code) : null, reason ?? null, expiresAt, actor],
  );

  if (rail === 'email') {
    try {
      await sendOtpEmail(config.MANAGER_EMAIL, code!, { purpose, claimId, amount: claim.amount, destination: claim.destination, reason });
    } catch (e) {
      await pool.query("UPDATE challenges SET status='expired' WHERE id=$1", [id]);
      log.error('OTP email failed', e);
      throw new GovernanceError(502, 'The email code could not be delivered, so approval cannot proceed (failing closed).');
    }
  } else {
    await publishStatus({ type: 'ping', claimId, detail: { challengeId: id, amount: claim.amount, destination: claim.destination, purpose } });
    if (config.NTFY_TOPIC_URL) {
      fetch(config.NTFY_TOPIC_URL, {
        method: 'POST',
        headers: { Title: 'LSG approval requested', Priority: 'high' },
        body: `Approve ${claim.amount} USDC to ${claim.destination}? Open the gateway to respond.`,
        signal: AbortSignal.timeout(8000),
      }).catch((e) => log.warn('ntfy push failed', e));
    }
  }
  await audit(pool, actor, 'challenge_requested', claimId, { rail, purpose, challengeId: id });
  return { challengeId: id, expiresAt: expiresAt.toISOString() };
}

/** Shared tail of every successful rail: record approval, flip to approved. Runs inside the caller's tx. */
async function finalize(c: PoolClient, claimId: string, purpose: Purpose, rail: Rail, actor: string, reason?: string) {
  const r = await c.query('SELECT status, amount, payable_amount FROM claims WHERE id = $1 FOR UPDATE', [claimId]);
  if (!r.rowCount) throw new GovernanceError(404, 'Claim not found.');
  assertState(r.rows[0].status, purpose);
  if (purpose === 'resettle' && r.rows[0].status === 'settled') {
    // Paying a fully settled claim again: the amount becomes payable once more (explicit, reasoned, Email-OTP approved).
    const next = await c.query('SELECT (COALESCE($1::numeric, $2::numeric) + $2::numeric) AS total', [r.rows[0].payable_amount, r.rows[0].amount]);
    if (Number(next.rows[0].total) > config.MAX_PAYOUT_USDC) throw new GovernanceError(409, 'Re-settlement would exceed the per-claim maximum.');
    await c.query('UPDATE claims SET payable_amount = $2 WHERE id = $1', [claimId, next.rows[0].total]);
  }
  await c.query('INSERT INTO approvals(id, claim_id, purpose, rail, approver, reason) VALUES ($1,$2,$3,$4,$5,$6)', [crypto.randomUUID(), claimId, purpose, rail, actor, reason ?? null]);
  await c.query("UPDATE claims SET status='approved', updated_at=now() WHERE id=$1", [claimId]);
  await audit(c, actor, purpose === 'resettle' ? 'resettlement_approved' : 'claim_approved', claimId, { rail, reason });
}

async function afterApproval(claimId: string) {
  await publishStatus({ type: 'claim', claimId, status: 'approved' });
  try {
    await publishSettlement({ claimId });
  } catch (e) {
    log.error('settlement enqueue failed; sweeper will retry', e);
  }
}

export async function respondPing(challengeId: string, decision: 'approve' | 'deny', actor: string) {
  const claimId = await tx(async (c) => {
    const r = await c.query('SELECT * FROM challenges WHERE id=$1 FOR UPDATE', [challengeId]);
    const ch = r.rows[0];
    if (!ch || ch.rail !== 'ping') throw new GovernanceError(404, 'Ping not found.');
    if (ch.status !== 'pending') throw new GovernanceError(409, 'Ping already answered or expired.');
    if (new Date(ch.expires_at) < new Date()) {
      await c.query("UPDATE challenges SET status='expired' WHERE id=$1", [challengeId]);
      throw new GovernanceError(410, 'Ping expired.');
    }
    if (decision === 'deny') {
      await c.query("UPDATE challenges SET status='denied' WHERE id=$1", [challengeId]);
      await audit(c, actor, 'ping_denied', ch.claim_id, {});
      return null;
    }
    await c.query("UPDATE challenges SET status='consumed' WHERE id=$1", [challengeId]);
    await finalize(c, ch.claim_id, ch.purpose, 'ping', actor);
    return ch.claim_id as string;
  }).catch((e) => {
    throw e;
  });
  if (claimId) await afterApproval(claimId);
  return { approved: !!claimId };
}

export async function approveWithPin(claimId: string, pin: string, actor: string) {
  const v = verifyPin(pin);
  if (v.locked) throw new GovernanceError(429, 'Access code locked after repeated failures. Try again later.');
  if (!v.ok) {
    await audit(pool, actor, 'pin_failed', claimId, {});
    throw new GovernanceError(403, 'Access code incorrect.');
  }
  await tx((c) => finalize(c, claimId, 'initial', 'pin', actor));
  await afterApproval(claimId);
}

export async function approveWithEmail(claimId: string, challengeId: string, code: string, actor: string) {
  type Outcome = { ok: true; reason?: string } | { ok: false; status: number; msg: string };
  const out = await tx<Outcome>(async (c) => {
    const r = await c.query('SELECT * FROM challenges WHERE id=$1 FOR UPDATE', [challengeId]);
    const ch = r.rows[0];
    if (!ch || ch.claim_id !== claimId || ch.rail !== 'email') return { ok: false, status: 404, msg: 'Code request not found.' };
    if (ch.status !== 'pending') return { ok: false, status: 409, msg: 'Code already used or expired.' };
    if (new Date(ch.expires_at) < new Date()) {
      await c.query("UPDATE challenges SET status='expired' WHERE id=$1", [challengeId]);
      return { ok: false, status: 410, msg: 'Code expired. Request a new one.' };
    }
    if (ch.attempts >= MAX_OTP_ATTEMPTS) {
      await c.query("UPDATE challenges SET status='expired' WHERE id=$1", [challengeId]);
      return { ok: false, status: 429, msg: 'Too many attempts. Request a new code.' };
    }
    const a = Buffer.from(otpMac(challengeId, code), 'hex');
    const b = Buffer.from(ch.code_hmac, 'hex');
    if (!/^\d{6}$/.test(code) || a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      await c.query('UPDATE challenges SET attempts = attempts + 1 WHERE id=$1', [challengeId]);
      await audit(c, actor, 'otp_failed', claimId, {});
      return { ok: false, status: 403, msg: 'Code incorrect.' };
    }
    await c.query("UPDATE challenges SET status='consumed' WHERE id=$1", [challengeId]);
    await finalize(c, claimId, ch.purpose, 'email', actor, ch.reason ?? undefined);
    return { ok: true };
  });
  if (!out.ok) throw new GovernanceError(out.status, out.msg);
  await afterApproval(claimId);
}
