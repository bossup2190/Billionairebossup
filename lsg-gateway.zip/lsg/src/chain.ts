import { JsonRpcProvider, Interface, getAddress, isAddress, formatUnits, id as keccak, ZeroAddress } from 'ethers';
import { config } from './config.js';

export const provider = new JsonRpcProvider(config.ETH_RPC_URL, config.CHAIN_ID, { staticNetwork: true });

const iface = new Interface(['event Transfer(address indexed from, address indexed to, uint256 value)']);
const TRANSFER_TOPIC = keccak('Transfer(address,address,uint256)');
const BURN = new Set([ZeroAddress, '0x000000000000000000000000000000000000dead']);

export async function chainPreflight(): Promise<void> {
  const net = await provider.getNetwork();
  if (Number(net.chainId) !== config.CHAIN_ID) throw new Error(`RPC chain id ${net.chainId} does not match CHAIN_ID ${config.CHAIN_ID}`);
  const code = await provider.getCode(config.USDC_CONTRACT);
  if (code === '0x') throw new Error('USDC_CONTRACT has no code on this chain');
}

export type DestCheck = { ok: true; address: string } | { ok: false; reason: string };

/** Live on-chain check of the payout destination. */
export async function validateDestination(raw: string): Promise<DestCheck> {
  if (!isAddress(raw)) return { ok: false, reason: 'Destination is not a valid Ethereum address (invalid checksum or format).' };
  const address = getAddress(raw);
  const lower = address.toLowerCase();
  if (BURN.has(lower)) return { ok: false, reason: 'Destination is a burn address.' };
  if (lower === config.USDC_CONTRACT.toLowerCase()) return { ok: false, reason: 'Destination is the USDC token contract itself; funds would be lost.' };
  if (lower === config.TREASURY_ETH_ADDRESS.toLowerCase()) return { ok: false, reason: 'Destination is the treasury deposit address.' };
  const code = await provider.getCode(address);
  if (code !== '0x' && !config.ALLOW_CONTRACT_DESTINATIONS)
    return { ok: false, reason: 'Destination is a smart contract. Only externally owned (personal) wallets are allowed.' };
  return { ok: true, address };
}

export interface VerifiedDeposit {
  logIndex: number;
  amount: string;
  from: string;
}

/** Verify a USDC deposit to the treasury address by transaction hash. Throws if unconfirmed or absent. */
export async function verifyDeposit(txHash: string): Promise<VerifiedDeposit[]> {
  if (!/^0x[a-fA-F0-9]{64}$/.test(txHash)) throw new Error('Invalid transaction hash.');
  const receipt = await provider.getTransactionReceipt(txHash);
  if (!receipt) throw new Error('Transaction not found on-chain.');
  if (receipt.status !== 1) throw new Error('Transaction reverted on-chain.');
  const confirmations = await receipt.confirmations();
  if (confirmations < config.MIN_CONFIRMATIONS)
    throw new Error(`Only ${confirmations} confirmations; ${config.MIN_CONFIRMATIONS} required.`);

  const out: VerifiedDeposit[] = [];
  for (const l of receipt.logs) {
    if (l.address.toLowerCase() !== config.USDC_CONTRACT.toLowerCase() || l.topics[0] !== TRANSFER_TOPIC) continue;
    const parsed = iface.parseLog({ topics: [...l.topics], data: l.data });
    if (!parsed || String(parsed.args.to).toLowerCase() !== config.TREASURY_ETH_ADDRESS.toLowerCase()) continue;
    out.push({ logIndex: l.index, amount: formatUnits(parsed.args.value as bigint, 6), from: String(parsed.args.from) });
  }
  if (!out.length) throw new Error('Transaction contains no USDC transfer to the treasury address.');
  return out;
}
