import amqp from 'amqplib';
import type { ConfirmChannel } from 'amqplib';
import { config } from './config.js';
import { log } from './mask.js';

type Conn = Awaited<ReturnType<typeof amqp.connect>>;
const Q = 'lsg.settlements';
const DLQ = 'lsg.settlements.dlq';
const X = 'lsg.status';

let conn: Conn | undefined;
let ch: ConfirmChannel | undefined;

export interface StatusEvent {
  type: 'claim' | 'ping' | 'ledger';
  claimId?: string;
  status?: string;
  detail?: Record<string, unknown>;
}

export async function connectQueue(): Promise<void> {
  conn = await amqp.connect(config.AMQP_URL);
  // Fail closed: if the broker connection drops, exit and let the orchestrator restart us.
  conn.on('close', () => {
    log.error('AMQP connection closed; exiting');
    process.exit(1);
  });
  conn.on('error', (e: unknown) => log.error('AMQP error', e));
  ch = await conn.createConfirmChannel();
  await ch.assertQueue(DLQ, { durable: true });
  await ch.assertQueue(Q, { durable: true, arguments: { 'x-dead-letter-exchange': '', 'x-dead-letter-routing-key': DLQ } });
  await ch.assertExchange(X, 'fanout', { durable: true });
}

function publish(exchange: string, key: string, payload: unknown, persistent: boolean): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!ch) return reject(new Error('queue not connected'));
    ch.publish(exchange, key, Buffer.from(JSON.stringify(payload)), { persistent, contentType: 'application/json' }, (err) =>
      err ? reject(err) : resolve(),
    );
  });
}

export const publishSettlement = (job: { claimId: string }) => publish('', Q, job, true);

/** Status fan-out is best effort; the database stays the source of truth. */
export async function publishStatus(evt: StatusEvent): Promise<void> {
  try {
    await publish(X, '', evt, false);
  } catch (e) {
    log.warn('status publish failed', e);
  }
}

export async function consumeSettlements(handler: (job: { claimId: string }) => Promise<void>): Promise<void> {
  await ch!.prefetch(1);
  await ch!.consume(Q, async (msg) => {
    if (!msg) return;
    try {
      await handler(JSON.parse(msg.content.toString()));
      ch!.ack(msg);
    } catch (e) {
      log.error('settlement job failed; dead-lettering', e);
      ch!.nack(msg, false, false);
    }
  });
}

export async function consumeStatus(handler: (evt: StatusEvent) => void): Promise<void> {
  const q = await ch!.assertQueue('', { exclusive: true, autoDelete: true });
  await ch!.bindQueue(q.queue, X, '');
  await ch!.consume(q.queue, (m) => {
    if (!m) return;
    try {
      handler(JSON.parse(m.content.toString()));
    } finally {
      ch!.ack(m);
    }
  });
}
