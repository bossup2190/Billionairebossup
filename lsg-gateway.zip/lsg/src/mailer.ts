import { config } from './config.js';
import { redactString } from './mask.js';

async function send(to: string, subject: string, text: string, html: string): Promise<void> {
  const res = await fetch('https://api.mailersend.com/v1/email', {
    method: 'POST',
    headers: { Authorization: `Bearer ${config.MAILERSEND_API_KEY}`, 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({
      from: { email: config.MAILERSEND_FROM_EMAIL, name: config.MAILERSEND_FROM_NAME },
      to: [{ email: to }],
      subject,
      text,
      html,
    }),
    signal: AbortSignal.timeout(15_000),
  });
  if (res.status !== 202) {
    const body = redactString((await res.text()).slice(0, 300));
    throw new Error(`MailerSend rejected the email (${res.status}): ${body}`);
  }
}

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

export async function sendOtpEmail(
  to: string,
  code: string,
  d: { purpose: 'initial' | 'resettle'; claimId: string; amount: string; destination: string; reason?: string },
): Promise<void> {
  const what = d.purpose === 'resettle' ? 'RE-SETTLEMENT' : 'settlement';
  const subject = `Approval code for ${what} of ${d.amount} USDC`;
  const lines = [
    `Approval code: ${code}`,
    '',
    `Action: approve ${what}`,
    `Claim: ${d.claimId}`,
    `Amount: ${d.amount} USDC (Ethereum)`,
    `Destination wallet: ${d.destination}`,
    ...(d.reason ? [`Reason: ${d.reason}`] : []),
    '',
    'Valid for 10 minutes, single use. If you did not expect this, do not enter the code and tell your security team.',
  ];
  const html = `<p><b>Approval code: <span style="font-size:22px;letter-spacing:3px">${esc(code)}</span></b></p>
<p>Action: approve ${esc(what)}<br>Claim: ${esc(d.claimId)}<br>Amount: ${esc(d.amount)} USDC (Ethereum)<br>Destination wallet: <code>${esc(d.destination)}</code>${
    d.reason ? `<br>Reason: ${esc(d.reason)}` : ''
  }</p><p>Valid for 10 minutes, single use. If you did not expect this, do not enter the code and tell your security team.</p>`;
  await send(to, subject, lines.join('\n'), html);
}
