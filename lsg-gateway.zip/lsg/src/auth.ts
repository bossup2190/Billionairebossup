import crypto from 'node:crypto';
import type { Request, RequestHandler } from 'express';
import { config } from './config.js';

export type Role = 'operator' | 'manager';

const h = (s: string) => crypto.createHash('sha256').update(s).digest();
const MANAGER = h(config.MANAGER_TOKEN);
const OPERATOR = h(config.OPERATOR_TOKEN);

export function roleOf(token: string | undefined): Role | null {
  if (!token) return null;
  const t = h(token);
  if (crypto.timingSafeEqual(t, MANAGER)) return 'manager';
  if (crypto.timingSafeEqual(t, OPERATOR)) return 'operator';
  return null;
}

export const tokenFrom = (req: Request): string | undefined => {
  const m = /^Bearer (.+)$/.exec(req.header('authorization') ?? '');
  return m?.[1];
};

/** Managers satisfy operator routes; operators never satisfy manager routes. */
export const requireRole =
  (min: Role): RequestHandler =>
  (req, res, next) => {
    const role = roleOf(tokenFrom(req));
    if (!role || (min === 'manager' && role !== 'manager')) {
      res.status(role ? 403 : 401).type('text/plain').send(role ? 'Forbidden: manager role required.' : 'Unauthorized.');
      return;
    }
    res.locals.role = role;
    res.locals.actor = role === 'manager' ? `manager:${config.MANAGER_EMAIL}` : 'operator';
    next();
  };

// ---- Access-code (PIN) rail ----
const attempts = { count: 0, lockedUntil: 0 };
const MAX_ATTEMPTS = 5;
const LOCK_MS = 15 * 60_000;

export function verifyPin(pin: string): { ok: boolean; locked?: boolean } {
  if (Date.now() < attempts.lockedUntil) return { ok: false, locked: true };
  let got: Buffer;
  let want: Buffer;
  if (config.MANAGER_PIN_HASH.startsWith('pbkdf2$')) {
    const [, iter, saltHex, hashHex] = config.MANAGER_PIN_HASH.split('$');
    want = Buffer.from(hashHex, 'hex');
    got = crypto.pbkdf2Sync(pin, Buffer.from(saltHex, 'hex'), Number(iter), want.length, 'sha256');
  } else {
    const [saltHex, hashHex] = config.MANAGER_PIN_HASH.split(':');
    got = crypto.scryptSync(pin, Buffer.from(saltHex, 'hex'), 32);
    want = Buffer.from(hashHex, 'hex');
  }
  const ok = got.length === want.length && crypto.timingSafeEqual(got, want);
  if (ok) {
    attempts.count = 0;
    return { ok: true };
  }
  if (++attempts.count >= MAX_ATTEMPTS) {
    attempts.lockedUntil = Date.now() + LOCK_MS;
    attempts.count = 0;
    return { ok: false, locked: true };
  }
  return { ok: false };
}
