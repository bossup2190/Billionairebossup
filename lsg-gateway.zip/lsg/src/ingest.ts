import { z } from 'zod';
import { XMLParser } from 'fast-xml-parser';
import { isAddress } from 'ethers';
import { config } from './config.js';
import type { Extracted } from './extract.js';

// ---------- Canonical claim metadata (validated with Zod) ----------
const BIC = /^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/;

export function ibanValid(raw: string): boolean {
  const iban = raw.replace(/\s+/g, '').toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(iban)) return false;
  const re = iban.slice(4) + iban.slice(0, 4);
  let rem = 0;
  for (const ch of re) {
    const v = ch >= 'A' ? String(ch.charCodeAt(0) - 55) : ch;
    for (const d of v) rem = (rem * 10 + Number(d)) % 97;
  }
  return rem === 1;
}

export const ClaimMeta = z.object({
  amount: z.string().regex(/^\d{1,18}(\.\d{1,6})?$/, 'amount is not a valid number').refine((v) => Number(v) > 0, 'amount must be positive'),
  asset: z.literal('USDC'),
  network: z.literal('ETH'),
  destination: z.string().regex(/^0x[a-fA-F0-9]{40}$/, 'destination is not a valid Ethereum address'),
  sourceKind: z.enum(['pain.001', 'pacs.008', 'json', 'document']),
  debtorBic: z.string().regex(BIC, 'debtor BIC is invalid').optional(),
  debtorIban: z.string().refine(ibanValid, 'debtor IBAN failed checksum').optional(),
  provenance: z.array(z.object({ field: z.string(), file: z.string(), via: z.string(), snippet: z.string().optional() })),
});
export type ClaimMeta = z.infer<typeof ClaimMeta>;

export type InputDoc = Extracted & { name: string };
export type Derived = { ok: true; meta: ClaimMeta } | { ok: false; reason: string };

interface Candidate {
  file: string;
  via: Extracted['kind'];
  amount?: string;
  currency?: string;
  address?: string;
  bic?: string;
  iban?: string;
  sourceKind: ClaimMeta['sourceKind'];
  snippet?: string;
}

class Reject extends Error {}
const rej = (m: string): never => {
  throw new Reject(m);
};

const arr = <T,>(v: T | T[] | undefined): T[] => (v === undefined ? [] : Array.isArray(v) ? v : [v]);
const txt = (v: unknown): string | undefined => {
  if (v == null) return undefined;
  if (typeof v === 'object') return (v as Record<string, unknown>)['#text'] != null ? String((v as Record<string, unknown>)['#text']) : undefined;
  return String(v);
};
const ADDR_RE = /0x[a-fA-F0-9]{40}/;

// ---------- ISO 20022 (pain.001 / pacs.008) ----------
function parseIso(doc: InputDoc): Candidate | null {
  const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_', removeNSPrefix: true, processEntities: false, parseTagValue: false });
  let root: Record<string, any>;
  try {
    root = parser.parse(doc.text)?.Document;
  } catch {
    return rej(`${doc.name}: XML is malformed.`);
  }
  if (!root) return null;

  let txs: Array<{ tx: any; dbtrAgt?: any; dbtrAcct?: any; amt: any }> = [];
  let sourceKind: Candidate['sourceKind'];
  if (root.CstmrCdtTrfInitn) {
    sourceKind = 'pain.001';
    for (const p of arr<any>(root.CstmrCdtTrfInitn.PmtInf))
      for (const tx of arr<any>(p.CdtTrfTxInf)) txs.push({ tx, dbtrAgt: p.DbtrAgt, dbtrAcct: p.DbtrAcct, amt: tx.Amt?.InstdAmt });
  } else if (root.FIToFICstmrCdtTrf) {
    sourceKind = 'pacs.008';
    for (const tx of arr<any>(root.FIToFICstmrCdtTrf.CdtTrfTxInf)) txs.push({ tx, dbtrAgt: tx.DbtrAgt, dbtrAcct: tx.DbtrAcct, amt: tx.IntrBkSttlmAmt });
  } else return null;

  if (txs.length !== 1) rej(`${doc.name}: expected exactly one credit transfer, found ${txs.length}. Submit one payout per claim.`);
  const { tx, dbtrAgt, dbtrAcct, amt } = txs[0];

  const bic = txt(dbtrAgt?.FinInstnId?.BICFI ?? dbtrAgt?.FinInstnId?.BIC);
  const iban = txt(dbtrAcct?.Id?.IBAN);
  if (!bic) rej(`${doc.name}: debtor BIC is missing.`);
  if (!iban) rej(`${doc.name}: debtor IBAN is missing.`);

  const amount = txt(amt);
  const currency = amt?.['@_Ccy'];
  let address = txt(tx.CdtrAcct?.Id?.Othr?.Id);
  if (!address || !ADDR_RE.test(address)) {
    const ustrd = arr<unknown>(tx.RmtInf?.Ustrd).map(String).join(' ');
    address = ustrd.match(ADDR_RE)?.[0];
  }
  return { file: doc.name, via: 'xml', amount, currency, address, bic: bic!.toUpperCase(), iban: iban!.replace(/\s+/g, '').toUpperCase(), sourceKind };
}

// ---------- JSON ----------
function parseJson(doc: InputDoc): Candidate | null {
  let j: any;
  try {
    j = JSON.parse(doc.text);
  } catch {
    return null;
  }
  if (!j || typeof j !== 'object') return null;
  const pick = (...keys: string[]) => {
    for (const [k, v] of Object.entries(j)) if (keys.includes(k.toLowerCase()) && v != null && typeof v !== 'object') return String(v);
  };
  const amount = pick('amount', 'total', 'amountdue', 'totalamount');
  const address = pick('destination', 'address', 'wallet', 'walletaddress', 'recipient', 'recipientaddress');
  if (!amount && !address) return null;
  return { file: doc.name, via: 'json', amount: amount?.replace(/,/g, ''), currency: pick('asset', 'currency', 'ccy'), address, sourceKind: 'json' };
}

// ---------- Free text (invoices: PDF text layer, OCR photos, txt/csv) ----------
const NUM = '(\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,6})?|\\d+(?:\\.\\d{1,6})?)';
const STRONG = '(?:grand\\s+total|total\\s+due|amount\\s+due|balance\\s+due|total\\s+amount|amount\\s+payable|amount\\s+to\\s+pay)';
const WEAK = '(?:total|amount|payment|pay)';
const money = (label: string) =>
  new RegExp(`\\b${label}\\b[^\\S\\n]*(?:\\((?:USDC|USD)\\))?[^\\S\\n]*[:\\-]?[^\\S\\n]*(?:USDC|USD|\\$)?[^\\S\\n]*${NUM}`, 'gi');

function parseText(doc: InputDoc): Candidate | null {
  let text = doc.text;
  if (doc.kind === 'ocr') text = text.replace(/\bO[xX](?=[0-9a-fA-F]{40}\b)/g, '0x');

  // Currency: be strict; mixed or foreign currencies are rejected.
  const hasUsdc = /\bUSDC\b|USD\s*Coin/i.test(text);
  const hasUsd = /\bUSD\b|\$/.test(text);
  const foreign = /\b(EUR|GBP|CHF|JPY|CAD|AUD|BTC|ETH)\b|[€£¥]/.exec(text);
  if (foreign && (hasUsd || hasUsdc)) rej(`${doc.name}: multiple currencies appear (${foreign[0]} and USD). Amount is ambiguous.`);
  const currency = hasUsdc ? 'USDC' : hasUsd ? 'USD' : foreign?.[0];

  // Amount: strongest label wins; distinct values at the same strength are ambiguous.
  let amount: string | undefined;
  let snippet: string | undefined;
  for (const label of [STRONG, WEAK]) {
    const seen = new Map<string, string>();
    for (const m of text.matchAll(money(label))) seen.set(Number(m[1].replace(/,/g, '')).toFixed(6), m[0].trim());
    if (seen.size > 1) rej(`${doc.name}: found conflicting amounts (${[...seen.keys()].map((k) => Number(k)).join(', ')}).`);
    if (seen.size === 1) {
      const [[k, s]] = [...seen];
      amount = String(Number(k));
      snippet = s;
      break;
    }
  }

  // Address: prefer labelled, otherwise a single unique address in the document.
  const all = new Set<string>();
  const labelled = new Set<string>();
  for (const m of text.matchAll(/0x[a-fA-F0-9]{40}/g)) {
    if (m[0].toLowerCase() === config.USDC_CONTRACT.toLowerCase()) continue;
    all.add(m[0]);
    const before = text.slice(Math.max(0, (m.index ?? 0) - 48), m.index);
    if (/(wallet|address|pay\s*to|send\s*to|destination|recipient|beneficiary)/i.test(before)) labelled.add(m[0]);
  }
  const pool = labelled.size ? labelled : all;
  const distinct = new Set([...pool].map((a) => a.toLowerCase()));
  if (distinct.size > 1) rej(`${doc.name}: multiple wallet addresses found; cannot tell which one to pay.`);
  const address = [...pool][0];

  if (!amount && !address) return null;
  return { file: doc.name, via: doc.kind, amount, currency, address, sourceKind: 'document', snippet };
}

// ---------- Orchestration ----------
export function deriveClaim(docs: InputDoc[]): Derived {
  try {
    const cands: Candidate[] = [];
    const notes: string[] = [];
    for (const d of docs) {
      let c: Candidate | null = null;
      if (d.kind === 'xml') c = parseIso(d);
      else if (d.kind === 'json') c = parseJson(d) ?? null;
      else if (d.kind === 'text' || d.kind === 'pdf-text' || d.kind === 'ocr') c = parseText(d);
      else if (d.note) notes.push(`${d.name}: ${d.note}`);
      if (c) cands.push(c);
    }
    if (!cands.length) rej(`No payable data could be extracted from the uploaded files. ${notes.join(' ')}`.trim());

    // Cross-document consistency: every source must agree.
    const amounts = new Set(cands.filter((c) => c.amount).map((c) => Number(c.amount!.replace(/,/g, '')).toFixed(6)));
    const addrs = new Set(cands.filter((c) => c.address).map((c) => c.address!.toLowerCase()));
    if (amounts.size === 0) rej('No amount could be found in the uploaded files.');
    if (addrs.size === 0) rej('No Ethereum wallet address could be found in the uploaded files.');
    if (amounts.size > 1) rej(`Uploaded files disagree on the amount (${[...amounts].map(Number).join(' vs ')}).`);
    if (addrs.size > 1) rej('Uploaded files disagree on the destination wallet address.');

    for (const c of cands) {
      const ccy = c.currency?.toUpperCase();
      if (!ccy) rej(`${c.file}: currency is not stated. Only USD/USDC is payable.`);
      if (ccy !== 'USD' && ccy !== 'USDC') {
        if (ccy === 'ETH') rej(`${c.file}: native ETH is not payable. Circle settles USDC on Ethereum; state the amount in USDC.`);
        rej(`${c.file}: currency ${ccy} is not payable. Only USD/USDC is supported.`);
      }
    }

    // Addresses read by OCR must carry a valid EIP-55 checksum: a single misread character would otherwise send funds to the wrong wallet.
    const addrSource = cands.find((c) => c.address)!;
    const address = addrSource.address!;
    const ocrOnly = cands.filter((c) => c.address).every((c) => c.via === 'ocr');
    if (ocrOnly) {
      const body = address.slice(2);
      const mixed = body !== body.toLowerCase() && body !== body.toUpperCase();
      if (!mixed || !isAddress(address)) rej('The wallet address was read from a photo and has no valid checksum casing, so it cannot be trusted. Upload a PDF/XML/JSON with the address, or a clearer photo with the checksummed address.');
    }

    const iso = cands.find((c) => c.sourceKind === 'pain.001' || c.sourceKind === 'pacs.008');
    const amountCand = cands.find((c) => c.amount)!;
    const prov: ClaimMeta['provenance'] = [
      { field: 'amount', file: amountCand.file, via: amountCand.via, snippet: amountCand.snippet },
      { field: 'destination', file: addrSource.file, via: addrSource.via },
    ];
    if (iso) prov.push({ field: 'debtorBic/debtorIban', file: iso.file, via: iso.via });

    const parsed = ClaimMeta.safeParse({
      amount: String(Number([...amounts][0])),
      asset: 'USDC',
      network: 'ETH',
      destination: address,
      sourceKind: iso?.sourceKind ?? addrSource.sourceKind,
      debtorBic: iso?.bic,
      debtorIban: iso?.iban,
      provenance: prov,
    });
    if (!parsed.success) rej(parsed.error.issues.map((i) => `${i.path.join('.') || 'claim'}: ${i.message}`).join('; '));
    return { ok: true, meta: (parsed as { data: ClaimMeta }).data };
  } catch (e) {
    if (e instanceof Reject) return { ok: false, reason: e.message };
    throw e;
  }
}
