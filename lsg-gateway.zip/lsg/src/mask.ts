// Credential masking: every log line, error message and API output passes through here.
const secrets = new Set<string>();

export function registerSecret(v: string | undefined): void {
  if (v && v.length >= 6) secrets.add(v);
}

const PATTERNS: Array<[RegExp, string | ((m: string) => string)]> = [
  [/\b(?:rk|sk|pk)_(?:live|test)_[A-Za-z0-9]+/g, '[REDACTED_KEY]'],
  [/\b(?:LIVE|TEST)_API_KEY:[A-Za-z0-9]+:[A-Za-z0-9]+/g, '[REDACTED_KEY]'],
  [/\bmlsn\.[A-Za-z0-9]+/g, '[REDACTED_KEY]'],
  [/\bAKIA[0-9A-Z]{16}\b/g, '[REDACTED_KEY]'],
  [/\bBearer\s+[A-Za-z0-9._~+\/=-]+/gi, 'Bearer [REDACTED]'],
  [/\b0x[a-fA-F0-9]{64}\b/g, '[REDACTED_HEX64]'],
  // IBAN: keep only the last four characters.
  [/\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b/g, (m) => `****${m.slice(-4)}`],
];

const SENSITIVE_KEY =
  /^(code|otp|pin|password|passwd|authorization|privatekey|private_key|mnemonic|seed)$|secret|token|api[-_]?key|signing|credential|hash$/i;
const PUBLIC_HEX_KEYS = /^(txhash|transactionhash|tx_hash|sha256|checksum)$/i;

export function redactString(input: string, keepHex = false): string {
  let out = input;
  for (const s of secrets) out = out.split(s).join('[REDACTED]');
  for (const [re, rep] of PATTERNS) {
    if (keepHex && re.source.includes('a-fA-F0-9]{64}')) continue;
    out = out.replace(re, rep as string);
  }
  return out;
}

export function redact(value: unknown, key = '', depth = 0): unknown {
  if (depth > 8) return '[TRUNCATED]';
  if (value == null) return value;
  if (key && SENSITIVE_KEY.test(key) && !PUBLIC_HEX_KEYS.test(key)) return '[REDACTED]';
  if (typeof value === 'string') return redactString(value, PUBLIC_HEX_KEYS.test(key));
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (value instanceof Error) return redactString(`${value.name}: ${value.message}`);
  if (Array.isArray(value)) return value.map((v) => redact(v, key, depth + 1));
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) out[k] = redact(v, k, depth + 1);
    return out;
  }
  return '[UNSERIALIZABLE]';
}

const write = (stream: NodeJS.WriteStream, level: string, msg: string, extra?: unknown) => {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    msg: redactString(msg),
    ...(extra === undefined ? {} : { data: redact(extra) }),
  });
  stream.write(line + '\n');
};

export const log = {
  info: (msg: string, extra?: unknown) => write(process.stdout, 'info', msg, extra),
  warn: (msg: string, extra?: unknown) => write(process.stdout, 'warn', msg, extra),
  error: (msg: string, extra?: unknown) => write(process.stderr, 'error', msg, extra),
};

// Route stray console.* calls through the masker too.
for (const level of ['log', 'info', 'warn', 'error'] as const) {
  console[level] = (...args: unknown[]) =>
    write(level === 'error' ? process.stderr : process.stdout, level, args.map((a) => (typeof a === 'string' ? a : JSON.stringify(redact(a)))).join(' '));
}
