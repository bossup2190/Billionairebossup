import pdfParse from 'pdf-parse/lib/pdf-parse.js';
import { createWorker } from 'tesseract.js';

export type ExtractKind = 'xml' | 'json' | 'text' | 'pdf-text' | 'ocr' | 'none';
export interface Extracted {
  kind: ExtractKind;
  text: string;
  confidence?: number; // OCR only, 0-100
  note?: string;
}

const IMAGE_MIME = /^image\/(png|jpe?g|bmp|webp)$/i;
const MIN_OCR_CONFIDENCE = 70;

type OcrWorker = Awaited<ReturnType<typeof createWorker>>;
let worker: OcrWorker | undefined;

async function ocr(buf: Buffer): Promise<{ text: string; confidence: number }> {
  worker ??= await createWorker('eng', 1, process.env.TESSDATA_PATH ? { langPath: process.env.TESSDATA_PATH, gzip: false } : {});
  const { data } = await worker.recognize(buf);
  return { text: data.text, confidence: data.confidence };
}

export async function extractText(buf: Buffer, mime: string, name: string): Promise<Extracted> {
  const lower = name.toLowerCase();
  const head = buf.subarray(0, 512).toString('utf8').trimStart();

  if (/\.xml$/.test(lower) || mime.includes('xml') || head.startsWith('<?xml') || head.startsWith('<Document'))
    return { kind: 'xml', text: buf.toString('utf8') };
  if (/\.json$/.test(lower) || mime === 'application/json') return { kind: 'json', text: buf.toString('utf8') };
  if (/\.(txt|csv|md)$/.test(lower) || mime.startsWith('text/')) return { kind: 'text', text: buf.toString('utf8') };

  if (mime === 'application/pdf' || /\.pdf$/.test(lower) || buf.subarray(0, 5).toString() === '%PDF-') {
    try {
      const { text } = await pdfParse(buf);
      if (text.trim().length >= 20) return { kind: 'pdf-text', text };
      return { kind: 'none', text: '', note: 'PDF has no text layer (scanned). Upload it as a PNG/JPEG photo so it can be read.' };
    } catch {
      return { kind: 'none', text: '', note: 'PDF could not be parsed.' };
    }
  }

  if (IMAGE_MIME.test(mime)) {
    try {
      const { text, confidence } = await ocr(buf);
      if (confidence < MIN_OCR_CONFIDENCE)
        return { kind: 'none', text: '', confidence, note: `Photo is too unclear to read reliably (OCR confidence ${Math.round(confidence)}%).` };
      return { kind: 'ocr', text, confidence };
    } catch {
      return { kind: 'none', text: '', note: 'Photo could not be read.' };
    }
  }

  return { kind: 'none', text: '', note: 'Stored as evidence; not machine-readable.' };
}
