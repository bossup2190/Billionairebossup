import crypto from 'node:crypto';
import type { PoolClient } from 'pg';
import { config } from './config.js';
import { pool, tx, audit } from './db.js';
import * as ledger from './ledger.js';
import * as circle from './circle.js';
import { validateDestination } from './chain.js';
import { publishSettlement, publishStatus } from './queue.js';
import { micro, fmt2, fromMicro, isCentPrecise } from './money.js';
import { log } from './mask.js';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const DAY_START = `(date_trunc('day', now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC')`;
const NEXT_DAY = `((date_trunc('day', now() AT TIME ZONE 'UTC') + interval '1 day') AT TIME ZONE 'UTC')`;

interface Plan {
  tranche: bigint; // amount to pay now (cent-precise)
  remaining: bigint; // still owed on this claim
  totalBlocked: boolean;
}

/**
 * Daily-tranche planner: pay min(remaining, room left in today's UTC cap, room left under the lifetime ceiling).
 * Runs inside SERIALIZABLE transactions, so concurrent settlements retry instead of overshooting a cap.
 */
async function plan(c: Pick<PoolClient, 'query'>, claim: { id: string; amount: string }): Promise<Plan> {
  const u = (
    await c.query(
      `SELECT COALESCE(SUM(amount) FILTER (WHERE created_at >= ${DAY_START}), 0)::text AS today,
              COALESCE(SUM(amount), 0)::text AS total,
              COALESCE(SUM(amount) FILTER (WHERE claim_id = $1), 0)::text AS mine
         FROM settlements WHERE status <> 'failed'`,
      [claim.id],
    )
  ).rows[0];
  const remaining = micro(claim.amount) - micro(u.mine);
  const dailyRoom = micro(String(config.DAILY_PAYOUT_CAP_USDC)) - micro(u.today);
  const totalRoom = micro(String(config.TOTAL_PAYOUT_CAP_USDC)) - micro(u.total);
  let tranche = [remaining, dailyRoom, totalRoom].reduce((a, b) => (b < a ? b : a));
  if (tranche < 0n) tranche = 0n;
  tranche -= tranche % 10_000n; // whole cents only
  return { tranche, remaining, totalBlocked: totalRoom <= 0n && remaining > 0n };
}

/** Re-verify everything immediately before money moves (approval may be hours old). */
async function finalGate(p: { amount: string; destination: string }): Promise<{ ok: true } | { ok: false; reason: string }> {
  try {
    if (!isCentPrecise(p.amount)) return { ok: false, reason: 'Amount is not cent-precise.' };
    const dest = await validateDestination(p.destination);
    if (!dest.ok) return { ok: false, reason: dest.reason };
    if (micro(await circle.availableUsd()) < micro(p.amount)) return { ok: false, reason: 'Settlement account balance is below this tranche amount.' };
    return { ok: true };
  } catch (e) {
    log.error('final gate error', e);
    return { ok: false, reason: 'Pre-settlement verification could not be completed; failing closed.' };
  }
}

async function failClaim(c: PoolClient, claimId: string, reason: string) {
  await c.query("UPDATE claims SET status='failed', rejection_reason=$2, updated_at=now() WHERE id=$1", [claimId, reason]);
  await audit(c, 'system', 'settlement_blocked', claimId, { reason });
}

/** One tranche: re-verify, reserve Master_Treasury -> Hot_Wallet, then pay via Circle. Approval covers all tranches. */
export async function runSettlement(claimId: string): Promise<void> {
  const live = (s: string) => s === 'approved' || s === 'tranching';
  const peek = (await pool.query('SELECT status, COALESCE(payable_amount, amount) AS amount, destination FROM claims WHERE id=$1', [claimId])).rows[0];
  if (!peek || !live(peek.status)) return; // duplicate or stale job
  const p0 = await plan(pool, { id: claimId, amount: peek.amount });
  const gate = p0.tranche > 0n ? await finalGate({ amount: fromMicro(p0.tranche), destination: peek.destination }) : ({ ok: true } as const);

  const sid = await tx(async (c) => {
    const claim = (await c.query('SELECT * FROM claims WHERE id=$1 FOR UPDATE', [claimId])).rows[0];
    if (!claim || !live(claim.status)) return null;
    if (claim.status === 'tranching' && claim.next_tranche_at && new Date(claim.next_tranche_at) > new Date()) return null;

    const p = await plan(c, { id: claimId, amount: claim.payable_amount ?? claim.amount });
    if (p.remaining <= 0n) {
      await c.query("UPDATE claims SET status='settled', updated_at=now() WHERE id=$1", [claimId]);
      return null;
    }
    if (p.totalBlocked) {
      await failClaim(c, claimId, `Total payout ceiling of ${config.TOTAL_PAYOUT_CAP_USDC} USDC reached; ${fromMicro(p.remaining)} USDC unpaid.`);
      return null;
    }
    if (p.tranche <= 0n) {
      // Today's tranche is used up: wait for the next UTC day. No new approval is needed.
      await c.query(`UPDATE claims SET status='tranching', next_tranche_at=${NEXT_DAY}, updated_at=now() WHERE id=$1`, [claimId]);
      return null;
    }
    if (!gate.ok) {
      await failClaim(c, claimId, gate.reason);
      return null;
    }
    if (p.tranche > p0.tranche) return null; // plan changed since verification; retried on the next sweep

    const amount = fromMicro(p.tranche);
    await ledger.lockAccount(c, ledger.TREASURY);
    if (!(await ledger.hasAtLeast(c, ledger.TREASURY, amount))) {
      await failClaim(c, claimId, 'Master_Treasury ledger balance is insufficient for this tranche.');
      return null;
    }
    const attempt = claim.settlement_count + 1;
    const id = crypto.randomUUID();
    await c.query("UPDATE claims SET status='settling', settlement_count=$2, updated_at=now() WHERE id=$1", [claimId, attempt]);
    await c.query(
      "INSERT INTO settlements(id, claim_id, attempt, idempotency_key, amount, destination, status) VALUES ($1,$2,$3,$4,$5,$6,'reserved')",
      [id, claimId, attempt, crypto.randomUUID(), amount, claim.destination],
    );
    await ledger.move(c, { claimId, kind: 'reserve', memo: 'Master_Treasury -> Hot_Wallet', ref: `reserve:${id}`, from: ledger.TREASURY, to: ledger.HOT, amount });
    await audit(c, 'system', 'tranche_reserved', claimId, { settlementId: id, attempt, amount, remainingAfter: fromMicro(p.remaining - p.tranche) });
    return id;
  });

  const st = (await pool.query('SELECT status FROM claims WHERE id=$1', [claimId])).rows[0]?.status;
  await publishStatus({ type: 'claim', claimId, status: st });
  if (sid) await submitAndWatch(sid, true);
}

async function recipientId(address: string): Promise<string> {
  const lower = address.toLowerCase();
  const hit = await pool.query('SELECT circle_address_id FROM recipients WHERE address=$1', [lower]);
  if (hit.rowCount) return hit.rows[0].circle_address_id;
  const id = await circle.createRecipient(address);
  await pool.query('INSERT INTO recipients(address, circle_address_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [lower, id]);
  return id;
}

async function submitAndWatch(sid: string, poll: boolean): Promise<void> {
  const s = (await pool.query('SELECT * FROM settlements WHERE id=$1', [sid])).rows[0];
  if (!s || s.status === 'complete' || s.status === 'failed') return;

  let t: circle.CircleTransfer;
  try {
    if (s.circle_transfer_id) t = await circle.getTransfer(s.circle_transfer_id);
    else {
      const addressId = await recipientId(s.destination);
      // Same idempotency key on every retry: Circle executes the transfer at most once.
      t = await circle.createTransfer({ idempotencyKey: s.idempotency_key, addressId, amount: fmt2(s.amount) });
      await pool.query("UPDATE settlements SET status='submitted', circle_address_id=$2, circle_transfer_id=$3, updated_at=now() WHERE id=$1", [sid, addressId, t.id]);
    }
  } catch (e) {
    if (e instanceof circle.CircleError && e.definitive && !s.circle_transfer_id) return failSettlement(sid, e.message);
    log.warn('Circle call uncertain; reconciler will retry with the same idempotency key', e);
    return;
  }

  for (let i = 0; ; i++) {
    if (await applyTransfer(sid, t)) return;
    if (!poll || i >= 20) return; // reconciler continues in the background
    await sleep(3000);
    try {
      t = await circle.getTransfer(t.id);
    } catch (e) {
      log.warn('transfer poll failed', e);
    }
  }
}

/** Returns true when the settlement reached a terminal state. */
async function applyTransfer(sid: string, t: circle.CircleTransfer): Promise<boolean> {
  if (t.status === 'complete') {
    await completeSettlement(sid, t.transactionHash ?? null);
    return true;
  }
  if (t.status === 'failed') {
    await failSettlement(sid, `Circle transfer failed${t.errorCode ? ` (${t.errorCode})` : ''}.`);
    return true;
  }
  if (t.transactionHash) await pool.query('UPDATE settlements SET tx_hash=$2, updated_at=now() WHERE id=$1', [sid, t.transactionHash]);
  return false;
}

async function completeSettlement(sid: string, txHash: string | null): Promise<void> {
  const done = await tx(async (c) => {
    const s = (await c.query('SELECT * FROM settlements WHERE id=$1 FOR UPDATE', [sid])).rows[0];
    if (!s || s.status === 'complete' || s.status === 'failed') return null;
    await ledger.move(c, { claimId: s.claim_id, kind: 'settle', memo: 'Hot_Wallet -> Recipient_Wallet', ref: `settle:${sid}`, from: ledger.HOT, to: ledger.recipientAccount(s.destination), amount: s.amount });
    await c.query("UPDATE settlements SET status='complete', tx_hash=COALESCE($2, tx_hash), updated_at=now() WHERE id=$1", [sid, txHash]);

    const claim = (await c.query('SELECT COALESCE(payable_amount, amount) AS amount FROM claims WHERE id=$1', [s.claim_id])).rows[0];
    const paid = (await c.query("SELECT COALESCE(SUM(amount),0)::text AS paid FROM settlements WHERE claim_id=$1 AND status <> 'failed'", [s.claim_id])).rows[0].paid;
    const left = micro(claim.amount) - micro(paid);
    if (left > 0n) {
      await c.query(`UPDATE claims SET status='tranching', rejection_reason=NULL, next_tranche_at=${NEXT_DAY}, updated_at=now() WHERE id=$1`, [s.claim_id]);
    } else {
      await c.query("UPDATE claims SET status='settled', rejection_reason=NULL, updated_at=now() WHERE id=$1", [s.claim_id]);
    }
    await audit(c, 'system', left > 0n ? 'tranche_settled' : 'settled', s.claim_id, { settlementId: sid, txHash, remaining: fromMicro(left) });
    return { claimId: s.claim_id as string, left };
  });
  if (done) await publishStatus({ type: 'claim', claimId: done.claimId, status: done.left > 0n ? 'tranching' : 'settled', detail: { txHash, remaining: fromMicro(done.left) } });
}

async function failSettlement(sid: string, reason: string): Promise<void> {
  const claimId = await tx(async (c) => {
    const s = (await c.query('SELECT * FROM settlements WHERE id=$1 FOR UPDATE', [sid])).rows[0];
    if (!s || s.status === 'complete' || s.status === 'failed') return null;
    await ledger.move(c, { claimId: s.claim_id, kind: 'reverse', memo: 'Hot_Wallet -> Master_Treasury (reversal)', ref: `reverse:${sid}`, from: ledger.HOT, to: ledger.TREASURY, amount: s.amount });
    await c.query("UPDATE settlements SET status='failed', error=$2, updated_at=now() WHERE id=$1", [sid, reason]);
    const paidBefore = await c.query("SELECT COALESCE(SUM(amount),0)::text AS paid FROM settlements WHERE claim_id=$1 AND status='complete'", [s.claim_id]);
    const paid = paidBefore.rows[0].paid;
    await failClaim(c, s.claim_id, micro(paid) > 0n ? `Partially paid (${paid} USDC). ${reason} Re-settle with an Email OTP to pay the remainder.` : reason);
    return s.claim_id as string;
  });
  if (claimId) await publishStatus({ type: 'claim', claimId, status: 'failed', detail: { reason } });
}

/** Background loop: resume in-flight transfers, start due daily tranches, re-enqueue lost approvals. */
export async function reconcile(): Promise<void> {
  const inflight = await pool.query("SELECT id FROM settlements WHERE status IN ('reserved','submitted') AND updated_at < now() - interval '20 seconds'");
  for (const r of inflight.rows) await submitAndWatch(r.id, false).catch((e) => log.error('reconcile failed', e));
  const due = await pool.query(
    `SELECT id FROM claims
      WHERE (status='approved' AND updated_at < now() - interval '30 seconds')
         OR (status='tranching' AND next_tranche_at <= now())`,
  );
  for (const r of due.rows) await publishSettlement({ claimId: r.id }).catch((e) => log.error('re-enqueue failed', e));
}
