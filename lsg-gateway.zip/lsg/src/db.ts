import pg from 'pg';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

export const pool = new pg.Pool({ connectionString: config.DATABASE_URL, max: 10 });
export type Db = pg.Pool | pg.PoolClient;

// Numeric columns come back as strings so no precision is lost.
pg.types.setTypeParser(1700, (v) => v);

/** Run fn in a SERIALIZABLE transaction, retrying serialization failures. */
export async function tx<T>(fn: (c: pg.PoolClient) => Promise<T>, attempts = 5): Promise<T> {
  for (let i = 0; ; i++) {
    const c = await pool.connect();
    try {
      await c.query('BEGIN ISOLATION LEVEL SERIALIZABLE');
      const out = await fn(c);
      await c.query('COMMIT');
      return out;
    } catch (e) {
      await c.query('ROLLBACK').catch(() => undefined);
      if ((e as { code?: string }).code === '40001' && i < attempts - 1) continue;
      throw e;
    } finally {
      c.release();
    }
  }
}

export async function audit(db: Db, actor: string, action: string, claimId: string | null, detail: unknown = {}): Promise<void> {
  const { redact } = await import('./mask.js');
  await db.query('INSERT INTO audit_log(actor, action, claim_id, detail) VALUES ($1,$2,$3,$4)', [
    actor,
    action,
    claimId,
    JSON.stringify(redact(detail)),
  ]);
}

export async function migrate(): Promise<void> {
  const sql = fs.readFileSync(path.resolve(process.cwd(), 'db/schema.sql'), 'utf8');
  await pool.query(sql);
}
