import crypto from 'node:crypto';
import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from 'pdf-lib';
import { config } from './config.js';

export type DocKind = 'pgl' | 'cis';

export interface DocInput {
  claimId: string;
  kind: DocKind;
  amount: string;
  destination: string;
  sourceKind: string;
  debtorBic?: string;
  debtorIban?: string;
  files: Array<{ name: string; sha256: string }>;
  provenance: Array<{ field: string; file: string; via: string }>;
  checks: string[];
  signerName: string;
  signedAt: Date;
  signaturePng: Buffer;
  verifiedAt: Date;
}

export interface StampedPdf {
  pdf: Buffer;
  stamp: string;
  payloadSha256: string;
  pdfSha256: string;
}

// Standard PDF fonts only cover Latin-1; replace anything else so rendering never throws.
const clean = (s: string) => s.replace(/[^\x20-\x7E -ÿ]/g, '?');
const maskIban = (v: string) => `${'*'.repeat(Math.max(0, v.length - 4))}${v.slice(-4)}`;

function wrap(text: string, font: PDFFont, size: number, maxW: number): string[] {
  const out: string[] = [];
  let line = '';
  for (const word of clean(text).split(/\s+/)) {
    const t = line ? `${line} ${word}` : word;
    if (font.widthOfTextAtSize(t, size) <= maxW) line = t;
    else {
      if (line) out.push(line);
      // Break very long tokens (addresses, hashes) by characters.
      let w = word;
      while (font.widthOfTextAtSize(w, size) > maxW) {
        let i = w.length;
        while (i > 1 && font.widthOfTextAtSize(w.slice(0, i), size) > maxW) i--;
        out.push(w.slice(0, i));
        w = w.slice(i);
      }
      line = w;
    }
  }
  if (line) out.push(line);
  return out;
}

export async function buildStampedPdf(i: DocInput): Promise<StampedPdf> {
  // The stamp seals the exact facts printed in the document.
  const payload = {
    kind: i.kind,
    claimId: i.claimId,
    amount: i.amount,
    asset: 'USDC',
    network: 'Ethereum',
    destination: i.destination.toLowerCase(),
    files: i.files.map((f) => f.sha256).sort(),
    signer: i.signerName,
    signedAt: i.signedAt.toISOString(),
    verifiedAt: i.verifiedAt.toISOString(),
  };
  const canonical = JSON.stringify(payload);
  const payloadSha256 = crypto.createHash('sha256').update(canonical).digest('hex');
  const mac = crypto.createHmac('sha256', config.DOC_SIGNING_SECRET).update(`${i.kind}|${canonical}`).digest('hex');
  const stamp = mac.slice(0, 32).toUpperCase().match(/.{8}/g)!.join('-');

  const pdf = await PDFDocument.create();
  const title = i.kind === 'pgl' ? 'Payment Guarantee Letter (PGL)' : 'Counterparty Information Sheet (CIS)';
  pdf.setTitle(`${title} - ${i.claimId}`);
  pdf.setAuthor('Liquidity Settlement Gateway');
  pdf.setSubject(`Stamp ${stamp}`);
  pdf.setCreationDate(i.verifiedAt);
  const reg = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const mono = await pdf.embedFont(StandardFonts.Courier);

  const page: PDFPage = pdf.addPage([595, 842]);
  const M = 48;
  const W = 595 - 2 * M;
  let y = 842 - M;
  const ink = rgb(0.1, 0.12, 0.16);
  const grey = rgb(0.4, 0.43, 0.48);

  page.drawRectangle({ x: 0, y: 842 - 92, width: 595, height: 92, color: rgb(0.06, 0.16, 0.3) });
  page.drawText('LIQUIDITY SETTLEMENT GATEWAY', { x: M, y: 842 - 40, size: 10, font: bold, color: rgb(0.7, 0.8, 0.95) });
  page.drawText(clean(title), { x: M, y: 842 - 68, size: 20, font: bold, color: rgb(1, 1, 1) });
  y = 842 - 92 - 30;

  const row = (label: string, value: string, f: PDFFont = reg) => {
    page.drawText(clean(label).toUpperCase(), { x: M, y, size: 7.5, font: bold, color: grey });
    y -= 12;
    for (const l of wrap(value, f, 10, W)) {
      page.drawText(l, { x: M, y, size: 10, font: f, color: ink });
      y -= 13;
    }
    y -= 6;
  };
  const para = (text: string) => {
    for (const l of wrap(text, reg, 10, W)) {
      page.drawText(l, { x: M, y, size: 10, font: reg, color: ink });
      y -= 14;
    }
    y -= 6;
  };
  const heading = (t: string) => {
    page.drawText(clean(t), { x: M, y, size: 12, font: bold, color: rgb(0.06, 0.16, 0.3) });
    y -= 6;
    page.drawLine({ start: { x: M, y }, end: { x: M + W, y }, thickness: 0.6, color: rgb(0.8, 0.83, 0.88) });
    y -= 16;
  };

  row('Reference (claim ID)', i.claimId, mono);
  row('Issued', i.verifiedAt.toISOString());

  if (i.kind === 'pgl') {
    heading('Statement');
    para(
      `This letter confirms that, at the time of issue, the gateway verified that liquidity of ${i.amount} USDC (USD Coin on the Ethereum network) is available for the payout described below, and that the destination wallet passed the on-chain checks listed in this document.`,
    );
    para(
      'Payment is conditional. Funds are released only after explicit manager approval through the gateway multi-rail authentication step-up. This letter is not an assurance of payment before that approval and is not issued by a bank or regulated custodian.',
    );
    heading('Payout');
    row('Amount', `${i.amount} USDC`, bold);
    row('Network', 'Ethereum (ERC-20 USDC)');
    row('Destination wallet', i.destination, mono);
    row('Status at issue', 'VERIFIED - PENDING MANAGER APPROVAL', bold);
  } else {
    heading('Counterparty and instruction');
    row('Beneficiary wallet', i.destination, mono);
    row('Amount / asset / network', `${i.amount} USDC on Ethereum`);
    row('Source document type', i.sourceKind);
    if (i.debtorBic) row('Debtor BIC', i.debtorBic);
    if (i.debtorIban) row('Debtor IBAN (masked)', maskIban(i.debtorIban), mono);
    heading('Verification checks passed');
    for (const c of i.checks) para(`- ${c}`);
    heading('Source files (SHA-256)');
    for (const f of i.files) {
      row(f.name, f.sha256, mono);
    }
    heading('Data extracted from');
    for (const p of i.provenance) para(`${p.field}: ${p.file} (${p.via})`);
  }

  // Signature block
  if (y < 250) y = 250;
  heading('Signed by');
  const sig = await pdf.embedPng(i.signaturePng);
  const scale = Math.min(220 / sig.width, 80 / sig.height, 1);
  const sw = sig.width * scale;
  const sh = sig.height * scale;
  page.drawImage(sig, { x: M, y: y - sh, width: sw, height: sh });
  y -= sh + 6;
  page.drawLine({ start: { x: M, y }, end: { x: M + 240, y }, thickness: 0.6, color: ink });
  y -= 13;
  page.drawText(clean(i.signerName), { x: M, y, size: 11, font: bold, color: ink });
  y -= 13;
  page.drawText(`Signed ${i.signedAt.toISOString()}`, { x: M, y, size: 8.5, font: reg, color: grey });

  // Digital stamp
  const sx = M + W - 190;
  const sy = 120;
  page.drawRectangle({ x: sx, y: sy, width: 190, height: 74, borderColor: rgb(0.06, 0.3, 0.55), borderWidth: 1.6, color: rgb(0.95, 0.97, 1) });
  page.drawText('LSG DIGITAL STAMP', { x: sx + 12, y: sy + 54, size: 10, font: bold, color: rgb(0.06, 0.3, 0.55) });
  page.drawText('HMAC-SHA256 seal', { x: sx + 12, y: sy + 41, size: 8, font: reg, color: ink });
  page.drawText(stamp.slice(0, 17), { x: sx + 12, y: sy + 26, size: 8.5, font: mono, color: ink });
  page.drawText(stamp.slice(18), { x: sx + 12, y: sy + 14, size: 8.5, font: mono, color: ink });

  page.drawText(clean(`Payload SHA-256: ${payloadSha256}`), { x: M, y: 64, size: 6.5, font: mono, color: grey });
  page.drawText('Verify this stamp with the gateway: GET /api/verify/<stamp>. A digital stamp proves integrity and origin within this gateway only.', {
    x: M,
    y: 52,
    size: 6.5,
    font: reg,
    color: grey,
  });

  const bytes = Buffer.from(await pdf.save());
  return { pdf: bytes, stamp, payloadSha256, pdfSha256: crypto.createHash('sha256').update(bytes).digest('hex') };
}
