// All dynamic content is inserted with textContent / createTextNode (never innerHTML).
const $ = (s, r = document) => r.querySelector(s);
const h = (tag, props = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const kid of kids.flat()) e.append(kid instanceof Node ? kid : document.createTextNode(kid ?? ''));
  return e;
};
const show = (el, on = true) => el.classList.toggle('hidden', !on);
const short = (a) => (a ? `${a.slice(0, 8)}…${a.slice(-6)}` : '');

let token = '';
let role = null;
let ws = null;
let selected = null;
let files = [];
let pendingPing = null;
try { token = sessionStorage.getItem('lsg_token') || ''; } catch { /* storage unavailable */ }

async function api(path, opts = {}) {
  const res = await fetch(path, { ...opts, headers: { ...(opts.headers || {}), Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error((await res.text()) || `Request failed (${res.status})`);
  return res;
}
const json = async (path, opts) => (await api(path, opts)).json();
const post = (path, body) => json(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

async function download(path, filename) {
  const blob = await (await api(path)).blob();
  const a = h('a', { href: URL.createObjectURL(blob), download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
}

// ---------- Sign in ----------
async function signIn(t) {
  token = t;
  const me = await json('/api/me');
  role = me.role;
  try { sessionStorage.setItem('lsg_token', token); } catch { /* ignore */ }
  show($('#login'), false);
  show($('#app'));
  $('#whoami').textContent = role === 'manager' ? 'Manager' : 'Operator';
  show($('#whoami'));
  show($('#signout'));
  show($('#injectCard'), role === 'manager');
  connectWs();
  await Promise.all([loadBalances(), loadClaims()]);
}
$('#go').addEventListener('click', async () => {
  try { await signIn($('#tok').value.trim()); } catch (e) {
    $('#loginErr').textContent = 'Sign-in failed. Check the token.';
    show($('#loginErr'));
  }
});
$('#tok').addEventListener('keydown', (e) => e.key === 'Enter' && $('#go').click());
$('#signout').addEventListener('click', () => { try { sessionStorage.removeItem('lsg_token'); } catch { /* ignore */ } location.reload(); });
if (token) signIn(token).catch(() => { token = ''; });

// ---------- Live status over WebSocket ----------
function connectWs() {
  ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  ws.addEventListener('open', () => ws.send(JSON.stringify({ type: 'auth', token })));
  ws.addEventListener('message', (m) => {
    const evt = JSON.parse(m.data);
    if (evt.type === 'claim') { loadClaims(); loadBalances(); if (selected === evt.claimId) openClaim(selected); }
    if (evt.type === 'ping' && role === 'manager') showPing(evt);
  });
  ws.addEventListener('close', () => setTimeout(() => token && connectWs(), 3000));
}

// ---------- Balances & claims ----------
async function loadBalances() {
  try {
    const b = await json('/api/ledger');
    const tile = (label, v) => h('div', {}, h('span', {}, label), h('b', {}, v == null ? 'unavailable' : `${Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`));
    $('#bal').replaceChildren(tile('Master treasury', b.masterTreasury), tile('Hot wallet', b.hotWallet), tile('Settlement acct (USD)', b.settlementAccountAvailableUsd));
    $('#depAddr').textContent = b.treasuryDepositAddress;
  } catch { /* balances are informational */ }
}
async function loadClaims() {
  const rows = await json('/api/claims');
  $('#claims').replaceChildren(...rows.map((c) =>
    h('tr', { class: c.id === selected ? 'sel' : '', onclick: () => openClaim(c.id) },
      h('td', {}, h('span', { class: `badge ${c.status}` }, c.status.replace('_', ' '))),
      h('td', {}, c.amount ? `${Number(c.amount).toLocaleString()} USDC` : '—'),
      h('td', { class: 'mono' }, short(c.destination) || '—'),
      h('td', {}, new Date(c.created_at).toLocaleString()))));
}

// ---------- File picker ----------
const picker = $('#picker');
const drop = $('#drop');
drop.addEventListener('click', () => picker.click());
drop.addEventListener('keydown', (e) => (e.key === 'Enter' || e.key === ' ') && picker.click());
picker.addEventListener('change', () => { addFiles([...picker.files]); picker.value = ''; });
['dragover', 'dragenter'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', (e) => addFiles([...e.dataTransfer.files]));
function addFiles(list) { files = [...files, ...list].slice(0, 10); renderFiles(); }
function renderFiles() {
  $('#fileList').replaceChildren(...files.map((f, i) =>
    h('li', {}, h('span', {}, `${f.name} (${(f.size / 1024).toFixed(0)} KB)`), h('button', { type: 'button', onclick: () => { files.splice(i, 1); renderFiles(); } }, 'Remove'))));
}

// ---------- Signature pad ----------
const canvas = $('#sig');
const ctx = canvas.getContext('2d');
let drawing = false, last = null, pts = 0;
const pos = (e) => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * (canvas.width / r.width), y: (e.clientY - r.top) * (canvas.height / r.height) }; };
ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#0b1f3a';
canvas.addEventListener('pointerdown', (e) => {
  canvas.setPointerCapture(e.pointerId); drawing = true; last = pos(e);
  ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(last.x, last.y, 2, 0, 6.3); ctx.fillStyle = '#0b1f3a'; ctx.fill(); pts += 3;
});
canvas.addEventListener('pointermove', (e) => {
  if (!drawing) return;
  const p = pos(e);
  const mid = { x: (last.x + p.x) / 2, y: (last.y + p.y) / 2 };
  const speed = Math.hypot(p.x - last.x, p.y - last.y);
  ctx.lineWidth = Math.max(2, Math.min(5.5, 6.5 - speed / 9)); // faster strokes thin out like a pen
  ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.quadraticCurveTo(last.x, last.y, mid.x, mid.y); ctx.stroke();
  last = mid; pts++;
});
const end = () => { drawing = false; };
canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end); canvas.addEventListener('pointerleave', end);
$('#sigClear').addEventListener('click', () => { ctx.clearRect(0, 0, canvas.width, canvas.height); pts = 0; });

// ---------- Submit ----------
$('#submit').addEventListener('click', async () => {
  const out = $('#result');
  out.replaceChildren();
  const name = $('#signer').value.trim();
  if (!files.length) return out.append(h('div', { class: 'note bad' }, 'Add at least one file or photo.'));
  if (name.length < 2) return out.append(h('div', { class: 'note bad' }, 'Enter your full name.'));
  if (pts < 25) return out.append(h('div', { class: 'note bad' }, 'Please sign in the signature box.'));
  if (!$('#agree').checked) return out.append(h('div', { class: 'note bad' }, 'Please confirm the declaration.'));

  const fd = new FormData();
  files.forEach((f) => fd.append('files', f, f.name));
  fd.append('signerName', name);
  fd.append('signature', canvas.toDataURL('image/png'));
  $('#submit').disabled = true; show($('#busy'));
  try {
    const r = await (await api('/api/claims', { method: 'POST', body: fd })).json();
    const e = r.extracted;
    out.append(
      h('div', { class: 'note ok' }, 'Verified. Your documents are stamped and ready. The payout now waits for manager approval.'),
      h('dl', { class: 'kv', style: 'margin-top:10px' },
        h('dt', {}, 'Amount'), h('dd', {}, `${e.amount} ${e.asset} on ${e.network}`),
        h('dt', {}, 'Wallet'), h('dd', { class: 'mono' }, e.destination),
        h('dt', {}, 'Read from'), h('dd', {}, e.provenance.map((p) => `${p.field}: ${p.file} (${p.via})`).join('; '))),
      h('div', { class: 'row', style: 'margin-top:10px' },
        h('button', { class: 'primary', onclick: () => download(`/api/claims/${r.claimId}/documents/pgl`, `PGL-${r.claimId}.pdf`) }, 'Download PGL'),
        h('button', { class: 'primary', onclick: () => download(`/api/claims/${r.claimId}/documents/cis`, `CIS-${r.claimId}.pdf`) }, 'Download CIS')));
    files = []; renderFiles(); $('#agree').checked = false; $('#sigClear').click();
    selected = r.claimId; await loadClaims(); openClaim(r.claimId);
  } catch (err) {
    out.append(h('pre', { class: 'note bad', style: 'font:inherit' }, err.message)); // plain-text rejection
    loadClaims();
  } finally { $('#submit').disabled = false; show($('#busy'), false); }
});

// ---------- Claim detail & approvals ----------
async function openClaim(id) {
  selected = id;
  const d = await json(`/api/claims/${id}`);
  const c = d.claim;
  const box = $('#detail');
  show(box);
  const kids = [
    h('h2', {}, 'Claim ', h('span', { class: 'mono' }, c.id)),
    h('p', {}, h('span', { class: `badge ${c.status}` }, c.status.replace('_', ' '))),
  ];
  if (c.rejection_reason) kids.push(h('pre', { class: 'note bad', style: 'font:inherit' }, c.rejection_reason));
  if (c.amount) kids.push(h('dl', { class: 'kv' },
    h('dt', {}, 'Amount'), h('dd', {}, `${c.amount} USDC (Ethereum)`),
    h('dt', {}, 'Wallet'), h('dd', { class: 'mono' }, c.destination),
    h('dt', {}, 'Source'), h('dd', {}, c.source_kind),
    h('dt', {}, 'Signed by'), h('dd', {}, c.metadata?.signer?.name ?? '')));

  if (d.stamps.length) kids.push(h('div', { class: 'row', style: 'margin:12px 0' },
    ...d.stamps.map((s) => h('button', { class: 'primary', onclick: () => download(`/api/claims/${id}/documents/${s.kind}`, `${s.kind.toUpperCase()}-${id}.pdf`) }, `Download ${s.kind.toUpperCase()}`))));

  if (role === 'manager' && d.files.length) kids.push(h('p', { class: 'sub' }, 'Original files: ',
    ...d.files.filter((f) => f.kind !== 'pgl' && f.kind !== 'cis').map((f) => h('button', { style: 'margin:2px', onclick: () => download(`/api/claims/${id}/files/${f.id}`, f.original_name) }, f.original_name))));

  if (c.status === 'awaiting_approval') kids.push(approvalPanel(id, 'initial'));
  if (c.status === 'tranching') kids.push(h('div', { class: 'note info' }, `Approved. Paying in daily tranches automatically; next tranche after ${new Date(c.next_tranche_at).toLocaleString()}. No further approval is needed.`));
  if (c.status === 'failed' || c.status === 'settled') kids.push(approvalPanel(id, 'resettle', c.status));

  if (d.approvals.length) kids.push(h('p', { class: 'sub' }, 'Approvals: ', d.approvals.map((a) => `${a.purpose} via ${a.rail}`).join(', ')));
  for (const s of d.settlements)
    kids.push(h('div', { class: 'note info' }, `Settlement #${s.attempt}: ${s.status}`, s.tx_hash ? `\ntx ${s.tx_hash}` : '', s.error ? `\n${s.error}` : ''));
  box.replaceChildren(...kids);
  loadClaims();
}

function approvalPanel(claimId, purpose, claimStatus) {
  const wrap = h('div', { class: 'card', style: 'background:var(--bg);margin-top:12px' });
  const msg = h('div');
  const say = (text, kind = 'info') => msg.replaceChildren(h('div', { class: `note ${kind}` }, text));
  const run = (fn) => async () => { try { await fn(); } catch (e) { say(e.message, 'bad'); } };
  wrap.append(h('h2', {}, purpose === 'resettle' ? 'Re-settle (Email OTP required)' : 'Approve payout'));
  if (purpose === 'resettle') wrap.append(h('p', { class: 'sub' }, claimStatus === 'settled' ? 'This claim is fully paid. Re-settling pays the full amount again.' : 'This pays only the unpaid remainder.'));
  let challengeId = null;
  const reason = h('textarea', { rows: '2', placeholder: 'Reason for re-settlement (min 10 characters)' });
  if (purpose === 'resettle') wrap.append(reason);

  const code = h('input', { type: 'text', inputmode: 'numeric', maxlength: '6', placeholder: '6-digit email code', autocomplete: 'one-time-code' });
  const emailRow = h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { onclick: run(async () => {
    const r = await post(`/api/claims/${claimId}/challenge`, { rail: 'email', purpose, reason: purpose === 'resettle' ? reason.value : undefined });
    challengeId = r.challengeId; say('A code was emailed to the approving manager. It expires in 10 minutes.');
  }) }, 'Email code'));
  if (role === 'manager') emailRow.append(code, h('button', { class: 'primary', onclick: run(async () => {
    if (!challengeId) throw new Error('Request an email code first.');
    await post(`/api/claims/${claimId}/approve/email`, { challengeId, code: code.value });
    say('Approved. Settlement is running.', 'ok'); setTimeout(() => openClaim(claimId), 800);
  }) }, 'Approve'));
  wrap.append(emailRow);

  if (purpose === 'initial') {
    wrap.append(h('div', { class: 'row', style: 'margin-top:8px' }, h('button', { onclick: run(async () => {
      await post(`/api/claims/${claimId}/challenge`, { rail: 'ping', purpose });
      say('Ping sent to the manager. Waiting for approval on their device…');
    }) }, 'Send ping')));
    if (role === 'manager') {
      const pin = h('input', { type: 'password', placeholder: 'Access code', autocomplete: 'off' });
      wrap.append(h('div', { class: 'row', style: 'margin-top:8px' }, pin, h('button', { class: 'primary', onclick: run(async () => {
        await post(`/api/claims/${claimId}/approve/pin`, { pin: pin.value }); pin.value = '';
        say('Approved. Settlement is running.', 'ok'); setTimeout(() => openClaim(claimId), 800);
      }) }, 'Approve with access code')));
    }
  }
  if (role !== 'manager') wrap.append(h('p', { class: 'sub' }, 'Only a manager can enter codes or approve. Requests above notify the manager.'));
  wrap.append(msg);
  return wrap;
}

// ---------- Manager ping dialog ----------
function showPing(evt) {
  pendingPing = evt;
  const d = evt.detail;
  $('#pingBody').replaceChildren(
    h('p', {}, `${d.purpose === 'resettle' ? 'Re-settle' : 'Pay'} ${Number(d.amount).toLocaleString()} USDC to`),
    h('p', { class: 'mono' }, d.destination), h('p', { class: 'mono' }, `Claim ${evt.claimId}`));
  $('#pingDlg').showModal();
}
async function answerPing(decision) {
  $('#pingDlg').close();
  if (!pendingPing) return;
  try { await post(`/api/challenges/${pendingPing.detail.challengeId}/respond`, { decision }); } catch (e) { alert(e.message); }
  openClaim(pendingPing.claimId); pendingPing = null;
}
$('#pingOk').addEventListener('click', () => answerPing('approve'));
$('#pingDeny').addEventListener('click', () => answerPing('deny'));

// ---------- Liquidity injection ----------
$('#inject').addEventListener('click', async () => {
  const out = $('#injectMsg');
  try {
    const r = await post('/api/liquidity/injections', { txHash: $('#txh').value.trim() });
    out.replaceChildren(h('div', { class: 'note ok' }, r.credited ? 'Deposit verified on-chain and credited to Master_Treasury.' : 'This deposit was already credited.'));
    $('#txh').value = ''; loadBalances();
  } catch (e) { out.replaceChildren(h('div', { class: 'note bad' }, e.message)); }
});

setInterval(() => token && role && loadClaims().catch(() => {}), 30_000);
